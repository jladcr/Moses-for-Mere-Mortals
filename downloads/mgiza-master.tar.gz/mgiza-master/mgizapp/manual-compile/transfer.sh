scp mgiza symal snt2plain snt2cooc-reduce-mem-preprocess snt2cooc plain2snt mkcls hmmnorm d4norm ../scripts/merge_alignment.py  s0565741@thor:/home/s0565741/RELEASE-1.0/binaries/mac-64bit/training-tools/mgiza

