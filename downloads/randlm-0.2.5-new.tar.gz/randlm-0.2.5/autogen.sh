#!/bin/sh

rm -Rf autom4te.cache
libtoolize --force && aclocal && autoconf && autoheader && automake --add-missing --copy
