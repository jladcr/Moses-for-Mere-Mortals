// Copyright 2008 David Talbot
//
// This file is part of RandLM
//
// RandLM is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// RandLM is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with RandLM.  If not, see <http://www.gnu.org/licenses/>.
#ifndef INC_BLOOM_MAP_H
#define INC_BLOOM_MAP_H

#include <map>
#include "LogFreqBloomFilter.h"

namespace randlm {

  struct Node {
    static const int kRootHeight = 63;  // indexed from 0 to 63
    static const uint64_t kOffsetMask = 0xffffffffffffffffull;
    // children either both present or both NULL (implies leaf)
    Node(uint64_t offset, int height) 
      : left_(NULL), right_(NULL), offset_(offset), 
	 height_(height), hash_idx_(0), code_(RandLMStruct::kNullCode) {
    }
    ~Node() { 
      delete left_;
      delete right_;
    }
    Node* left_;
    Node* right_;  
    uint64_t offset_; // used to recycle hash functions
    int height_; // level in tree root is at height 64
    int hash_idx_;  // holder for hash idx
    int code_;  // stores valid code on leaves only
  };

  // The BloomMap is described in Talbot and Talbot (ANALCO 2008).
  // It makes use of the distribution over values (e.g. counts) and
  // encodes each value with a separate set of hash functions using
  // on average O(log 1/p_i + log 1/epsilon) hash functions per key.
  
  // Current implementation maintains separate set of codes for each 
  // EventType. (Distinct order ngrams could have their own code sets.)

  class BloomMap : public LogFreqBloomFilter {
  public:
    BloomMap(RandLMInfo* info) : RandLMStruct(info),
      LogFreqBloomFilter(info), root_(NULL),
      code_to_leaf_(NULL), code_to_path_len_(NULL),
      code_to_bound_(NULL) {
      assert(info->getEstimator() == kBatchEstimationCode);
    }
    BloomMap(RandLMInfo* info, RandLMFile* fin) 
      : RandLMStruct(info, fin), 
      LogFreqBloomFilter(info, fin), root_(NULL),
      code_to_leaf_(NULL), code_to_path_len_(NULL),
      code_to_bound_(NULL) {
      assert(load(fin)); // load own data
    }
    ~BloomMap() {
      if (code_to_leaf_ != NULL){
	for (int i = 0; i < num_events_; ++i) {
	  delete[] code_to_leaf_[i];
	  delete[] code_to_path_len_[i];
	  delete[] code_to_bound_[i];
	}
	delete[] code_to_leaf_;
	delete[] code_to_path_len_;
	delete[] code_to_bound_;
      }
      if (root_ != NULL) {
	for (int i = 0; i < num_events_; ++i)
	  delete root_[i];
	delete[] root_;
      }
    }
    // client functions
    bool insert(const WordID* ngram, int len, int event_idx, int code);
    bool query(const WordID* ngram, int len, int event_idx, int* code, int max);
    bool query(const WordID word, int start, int end, int event_idx, int* code, int max);
    bool setCodeCounts(CodeCounts codes, uint64_t total, int event_idx, int order = 0);
    bool optimise(float working_mem);
    bool save(RandLMFile* file);    
    bool printCounters(int event_idx, int len);
  protected:
    bool printID(uint64_t id);
    bool load(RandLMFile* fin);
    int getMaxHashes(int event_idx);
    uint64_t computeTotalHashes();
    int getCodeLength(int event_idx, int code); // returns total number of hashes for code
    bool computePaths();  // compute near-optimal alphabetic binary tree
    bool partitionCodes(std::map<int, std::pair<double, std::pair<uint64_t, int> > > &qs, 
			int depth, std::map<int, std::pair<uint64_t, int> > &paths);
    bool setupCodingTree();   // instantiate tree from set of paths
    bool addPath(int code, uint64_t path, int len, Node* node);
    std::map<int, std::map<int, std::map<int, uint64_t> > > counters_;  
    Node** root_;  // root(s) to coding trees
    // mappings needed since codes not observed are not assigned a path / leaf 
    uint64_t** code_to_leaf_;  // map from codes to leaf ids (leaf ids are contiguous)
    int** code_to_path_len_;  // map from codes to length of paths
    int** code_to_bound_;  // maximum length path for code <= this (used for cache)
  };
}

#endif // INC_BLOOM_MAP_H
