// Copyright 2008 David Talbot
//
// This file is part of RandLM
//
// RandLM is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// RandLM is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with RandLM.  If not, see <http://www.gnu.org/licenses/>.
#include "BloomierFilter.h"

namespace randlm {

  bool BloomierFilter::insert(const WordID* ngram, int len, int event_idx, int code) {
    return true;
  }

  bool BloomierFilter::query(const WordID* ngram, int len, int event_idx, int* code, int max) {
    return true;
  }

  bool BloomierFilter::query(const WordID word, int start, int end, int event_idx, int* code, int max) {
    return true;
  }

  bool BloomierFilter::optimise(float working_mem) {
    return false;
  }

  bool BloomierFilter::load(RandLMFile* fin) {
    return true;
  }

  bool BloomierFilter::initMembers() {
    return true;
  }

  bool BloomierFilter::save(RandLMFile* fout) {
    assert(fout != NULL && StaticRandLMStruct::save(fout));
    return true;
  }
  
}

