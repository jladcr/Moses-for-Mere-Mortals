// Copyright 2008 David Talbot
//
// This file is part of RandLM
//
// RandLM is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// RandLM is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with RandLM.  If not, see <http://www.gnu.org/licenses/>.
#ifndef INC_BLOOMIER_FILTER_H
#define INC_BLOOMIER_FILTER_H

#include "RandLM.h"
#include "RandLMFilter.h"
#include "RandLMStruct.h"

namespace randlm {
  // The BloomierFilter is described in (Chazelle et al., 2004)
  // it uses a perfect hash function described in (Majewski et al., 1996)
  // A language model using it is described in (Talbot and Brants, 2008).
  // The perfect hash function is a small factor (1.23) from optimal.
  // It permits false positives but no misassignments. Values assigned 
  // as false positives are uniformly distributed over the range of valid values.
  class BloomierFilter : public StaticRandLMStruct {
  public:
    BloomierFilter(RandLMInfo* info) : StaticRandLMStruct(info) {
      assert(initMembers());
    }
    BloomierFilter(RandLMInfo* info, RandLMFile* fin) 
      : StaticRandLMStruct(info, fin) {
      assert(initMembers());
      assert(load(fin));
    }
    // client functions
    bool insert(const WordID* ngram, int len, int event_idx, int code);
    bool query(const WordID* ngram, int len, int event_idx, int* code, int max);
    bool query(const WordID word, int start, int end, int event_idx, int* code, int max);
    bool optimise(float working_mem);
    bool save(RandLMFile* file);
    uint64_t getSize() { return 0; }
  protected:
    // i/o
    bool initMembers();
    bool load(RandLMFile* file);  
    Filter<uint32_t>*** filters_;  // multiple bloomier filters      
    WordID* index_[RandLM::kMaxNgramOrder];  // index for each filter
  };
}

#endif // INC_BLOOMIER_FILTER_H

