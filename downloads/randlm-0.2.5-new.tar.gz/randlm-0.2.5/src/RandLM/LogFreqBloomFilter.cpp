// Copyright 2008 David Talbot
//
// This file is part of RandLM
//
// RandLM is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// RandLM is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with RandLM.  If not, see <http://www.gnu.org/licenses/>.
#include "LogFreqBloomFilter.h"

namespace randlm {

  bool LogFreqBloomFilter::insert(const WordID* ngram, int len, int event_idx, int code) {
    // insert code to filter using appropriate hash functions
    assert(optimised_ && !full_);
    int idx = 0;
    int insertions = alpha_[len - 1] + (code * k_[len - 1]);
    while (idx < insertions) {
      assert(filter_->setBit(hashes_[event_idx][idx]->hash(ngram, len)));
      ++idx;
    }
    inserted_ += insertions;    
    full_ = inserted_ > t_;  // indicate to caller if full 
    return !full_;
  }

  bool LogFreqBloomFilter::query(const WordID* ngram, int len, int event_idx, int* code, int max) {
    // query filter for this ngram map to code on basis of num of hash functions that test true
    int idx = 0;
    // determine the maximum number of hashes given upper bound 'max' on 'code'
    int max_idx = std::min(max_hashes_[event_idx], alpha_[len - 1] + (max * k_[len - 1]));
    while (idx < max_idx) {
      if(!filter_->testBit(hashes_[event_idx][idx]->hash(ngram, len)))
	break;
      ++idx;
    }  
    // convert from hash index to code
    *code = (idx  < alpha_[len - 1]) ? kNullCode : (idx - alpha_[len-1]) / k_[len - 1];
    return *code != kNullCode;
  }
  
  bool LogFreqBloomFilter::query(const WordID word, int start, int end, int event_idx, int* code, int max) {
    // get first bound on hash functions
    //std::cerr <<"q:" << event_idx << " " << start << " " << end << " " << max;
    int idx = 0;
    int max_idx = std::min(max_hashes_[event_idx], alpha_[end - start] + (max * k_[end - start]));
    if (start == end) // implies first query
      used_[event_idx][end] = 0;
    else
      max_idx = std::min(max_idx, used_[event_idx][end]); // relies on falsepos(n) >= falsepos(n+1)
    // check for hashes
    while (idx < max_idx) {
      if (start == end)  // reset cache for unigram
	values_[event_idx][end][idx] = 0;
      else 
	assert(used_[event_idx][end] > idx);
      if(!filter_->testBit(hashes_[event_idx][idx]->increment(word, end - start, 
							      values_[event_idx][end][idx], 
							      &values_[event_idx][end][idx])))
	break;
      ++idx;
    }
    used_[event_idx][end] = idx;
    // convert from hash index to code
    *code = (idx  < alpha_[end - start]) ? kNullCode : (idx - alpha_[end - start]) / k_[end - start];
    return *code != kNullCode;
  }

  // used by RandLM to inform RandLMStruct what data will be inserted
  bool LogFreqBloomFilter::setCodeCounts(CodeCounts counts, uint64_t total, 
					 int event_idx, int order) {
    assert(!optimised_);  // don't call optimise prior to specifying
    // determine unary encoding size of these codes
    assert(order_specific_ || order == 0);
    assert(order - order_specific_ >= 0 && order <= order_);
    if (!stats_counters_)
      assert(initStatsCounters());
    for (CodeCounts::iterator iter = counts.begin(); iter != counts.end(); ++iter) {
      int code = iter->first;
      uint64_t freq = iter->second;
      // unary increment for code counts additional insertions beyond count of code = 0
      unary_increments_[event_idx][order_specific_ ? order - 1 : 0] += (code * freq); // increments
      // objects counts number of objects
      objects_[event_idx][order_specific_ ? order - 1 : 0] += freq; // number of events
      // keep track of max / min codes per eventtype
      max_code_[event_idx] = code > max_code_[event_idx] ? code : max_code_[event_idx];
      min_code_[event_idx] = code < min_code_[event_idx] ? code : min_code_[event_idx];
    }
    return true;
  }

  // called by RandLM afer setCodeCounts has been called for all data
  bool LogFreqBloomFilter::optimise(float working_mem) {
    assert(!optimised_);  // only call once
    // optimise error/space 
    assert(info_ != NULL);
    assert(info_->hasFalsePosSpec() || info_->hasMemorySpec());
    assert(!info_->hasFalseNegSpec());  // can't have false neg
    if (info_->hasFalsePosSpec())
      assert(setParameters());  // set from error rate
    else
      assert(inferParameters()); // infer from memory setting
    assert(setupFilter());  // create filter and hash functions
    optimised_ = true;
    return true;
  }
  
  bool LogFreqBloomFilter::initStatsCounters() {
    // set up data structures
    assert(!stats_counters_);
    unary_increments_ = new uint64_t*[num_events_];
    objects_ = new uint64_t*[num_events_];
    for (int i = 0; i < num_events_; ++i) {
      unary_increments_[i] = new uint64_t[order_specific_ ? order_ : 1];
      objects_[i] = new uint64_t[order_specific_ ? order_ : 1];
      for (int j = 0; j < (order_specific_ ? order_ : 1); ++j) {
	unary_increments_[i][j] = 0;
	objects_[i][j] = 0;
      }
    }
    stats_counters_ = true;
    return true;
  }
  
  bool LogFreqBloomFilter::setParameters() {
    assert(info_ != NULL);
    // set paramters from error specifications
    assert(info_->hasFalsePosSpec());
    alpha_ = new int[order_];
    k_ = new int[order_];
    for (int i = 0; i < order_; ++i) {
      alpha_[i] = 0;
      k_[i] = 0;
    }
    max_alpha_ = 0; 
    max_k_ = 0; 
    // determine number of hash functions required given error rates
    for (int i = 0; i < order_; ++i) {
      // constraint on this structure that error rates do not decrease with n
      if (i > 0) { // caching mechanism relies on this
	assert(!(info_->getFalsePos(i + 1) + info_->getFailProb(i + 1) >
		 info_->getFalsePos(i) + info_->getFailProb(i)));
	assert(!(info_->getMisassign(i + 1) + info_->getFailProb(i + 1) >
		 info_->getMisassign(i) + info_->getFailProb(i)));
      }
      // round up use false pos rate for alpha_ (add fail prob)
      alpha_[i] = static_cast<int>(ceil(info_->getFalsePos(i + 1) + 
					info_->getFailProb(i + 1)));
      // use misassigment rate (or false pos rate if none) for k_
      k_[i] = static_cast<int>(ceil((info_->hasMisassignSpec() ? info_->getMisassign(i + 1) : 
				     info_->getFalsePos(i + 1)) + info_->getFailProb(i + 1)));
      assert(k_[i] > 0 && alpha_[i] > 0);
      max_alpha_ = alpha_[i] > max_alpha_ ? alpha_[i] : max_alpha_;
      max_k_ = k_[i] > max_k_ ? k_[i] : max_k_;
    }
    return true;
  }

  bool LogFreqBloomFilter::inferParameters() {
    // determine best rate given memory constraint (not order specific)
    assert(info_->hasMemorySpec() && !order_specific_
	   && info_->getEstimator() == RandLMStruct::kBatchEstimationCode);
    alpha_ = new int[order_];
    k_ = new int[order_];
    for (int i = 0; i < order_; ++i) {
      alpha_[i] = 0;
      k_[i] = 0;
    }
    max_alpha_ = 0;
    max_k_ = 0;
    // implied total hashes based on memory requirement
    uint64_t desired_total = static_cast<uint64_t>(static_cast<uint64_t>(info_->getMemory() 
									 * (1ull << 23)) * log(2));
    uint64_t actual_total = 0;
    for (int i = 0; i < num_events_; ++i)
      actual_total += objects_[i][0] + unary_increments_[i][0];  // no other stats
    // choose number of hash functions such that t hashes will actually be used in total
    for (int i = 0; i < order_; ++i) {
      alpha_[i] = static_cast<int>(floor(static_cast<double>(desired_total)
					 /static_cast<double>(actual_total)));
      k_[i] = alpha_[i];  // set as same false pos rate
      assert(k_[i] > 0 && alpha_[i] > 0);
      max_alpha_ = alpha_[i] > max_alpha_ ? alpha_[i] : max_alpha_;
      max_k_ = k_[i] > max_k_ ? k_[i] : max_k_;
    }
    return true;
  }
 
  uint64_t LogFreqBloomFilter::computeTotalHashes() {
    // calculate how many hashes will be made into filter
    uint64_t total = 0;
    for (int i = 0; i < num_events_; ++i)
      for (int j = 0; j < (order_specific_ ? order_ : 1); ++j) {
	total += static_cast<uint64_t>(alpha_[j]) * objects_[i][j];  // all objects use this many insertions
	total += static_cast<uint64_t>(k_[j]) * unary_increments_[i][j];  // larger codes requ additional ones
      }
    return total;
  }

  int LogFreqBloomFilter::getMaxHashes(int event_idx) {
    // simple for unary encoding
    assert(max_alpha_ > 0 && max_k_ > 0 && max_code_ > 0);
    return max_alpha_ + (max_k_ * max_code_[event_idx]);
  }

  bool LogFreqBloomFilter::setupFilter() {
    // compute m and t based on stats and hash parameters
    t_ = computeTotalHashes();  // total hashes into filter
    // determine optimal m = t / ln(2) (choose next prime)
    m_ = RandLMUtils::NextPrime(static_cast<uint64_t>(ceil(static_cast<double>(t_) / log(2))));
    // set up filter 
    filter_ = new BitFilter(m_);
    // set up hash functions
    hashes_ = new UniversalHash<uint64_t>**[num_events_];
    // upper bound on number of hash functions needed
    max_hashes_ = new int[num_events_];
    for (int i = 0; i < num_events_; ++i)
      max_hashes_[i] = 0;
    for (int i = 0; i < num_events_; ++i) {
      max_hashes_[i] = getMaxHashes(i);
      assert(max_hashes_[i] > 0);
      std::cerr << "Using " << max_hashes_[i] << " hash functions." << std::endl;
      hashes_[i] = new UniversalHash<uint64_t>*[max_hashes_[i]];
      // instantiate a set of new hash functions
      for (int j = 0; j < max_hashes_[i]; ++j)
	hashes_[i][j] = new UniversalHash<uint64_t>(m_, order_);
    }
    std::cerr << "Memory = " << m_ << " bits (" << static_cast<float>(m_) / static_cast<float>(1ull << 23)
	      << "MB)"<< std::endl;
    // keep track of total insertions during construction
    inserted_ = 0;
    return true;
  }

  bool LogFreqBloomFilter::save(RandLMFile* fout) {
    // save all the specific data here (save parent first)
    assert(RandLMStruct::save(fout));
    assert(fout != NULL);
    assert(fout->write((char*)&m_, sizeof(m_)));
    assert(fout->write((char*)&t_, sizeof(t_)));
    assert(fout->write((char*)&inserted_, sizeof(inserted_)));
    assert(filter_ != NULL);
    assert(filter_->save(fout));
    for (int i = 0; i < num_events_; ++i) {
      assert(fout->write((char*)&max_hashes_[i], sizeof(max_hashes_[i])));
      std::cerr << "Writing " << max_hashes_[i] << " hash functions." << std::endl;
      for (int j = 0; j < max_hashes_[i]; ++j)
	assert(hashes_[i][j]->save(fout));
    }
    for (int i = 0; i < order_; ++i) {
      assert(fout->write((char*)&alpha_[i], sizeof(alpha_[i])));
      assert(fout->write((char*)&k_[i], sizeof(k_[i])));
    }
    assert(fout->write((char*)&max_alpha_, sizeof(max_alpha_)));
    assert(fout->write((char*)&max_k_, sizeof(max_k_)));
    return true;
  }

  bool LogFreqBloomFilter::setupCache(int max_cache) {
    // storage for local caching and bounding of hashes
    assert(max_cache_ == 0);  
    max_cache_ = max_cache;
    used_ = new int*[num_events_];
    values_ = new uint64_t**[num_events_];
    for (int i = 0; i < num_events_; ++i) {
      used_[i] = new int[max_cache_];
      values_[i] = new uint64_t*[max_cache_];
      for(int j = 0; j < max_cache_; ++j) {
	used_[i][j] = 0;
	values_[i][j] = new uint64_t[max_hashes_[i]];
	for (int k = 0; k < max_hashes_[i]; ++k)
	  values_[i][j][k] = 0;
      }
    }
    return true;
  }

  bool LogFreqBloomFilter::load(RandLMFile* fin) {
    // load all member data in
    assert(fin != NULL);
    assert(filter_ == NULL);
    assert(fin->read((char*)&m_, sizeof(m_)));
    assert(fin->read((char*)&t_, sizeof(t_)));
    assert(fin->read((char*)&inserted_, sizeof(inserted_)));
    // resize filter if more than 10% slack
    filter_ = NULL;
    if (static_cast<float>(inserted_) > 0.90 * static_cast<float>(t_)) {
      filter_ = new BitFilter(fin);
    } else {
      std::cerr << "Optimising filter size from " 
		<< static_cast<float>(m_)/static_cast<float>(1ull<<23) << " to " 
    		<< (static_cast<float>(inserted_)/log(2.0))/static_cast<float>(1ull<<23) << std::endl;
      filter_ = new ResizedBitFilter(fin, static_cast<uint64_t>(static_cast<float>(inserted_) / log(2.0)));
    }
    assert(filter_ != NULL);
    hashes_ = new UniversalHash<uint64_t>**[num_events_];
    max_hashes_ = new int[num_events_];
    for (int i = 0; i < num_events_; ++i) {
      assert(fin->read((char*)&max_hashes_[i], sizeof(max_hashes_[i])));
      std::cerr << "Loading " << max_hashes_[i] << " hash functions" << std::endl;
      hashes_[i] = new UniversalHash<uint64_t>*[max_hashes_[i]];
      for (int j = 0; j < max_hashes_[i]; ++j) {
	hashes_[i][j] = new UniversalHash<uint64_t>(fin);
	assert(hashes_[i][j]->getRange() == m_);
	assert(hashes_[i][j]->getOrder() == order_);
      }
    }
    alpha_ = new int[order_];
    k_ = new int[order_];
    for (int i = 0; i < order_; ++i) {
      assert(fin->read((char*)&alpha_[i], sizeof(alpha_[i])));
      assert(fin->read((char*)&k_[i], sizeof(k_[i])));
    }
    assert(fin->read((char*)&max_alpha_, sizeof(max_alpha_)));
    assert(fin->read((char*)&max_k_, sizeof(max_k_)));
    return true;
  }

}
