// Copyright 2008 David Talbot
//
// This file is part of RandLM
//
// RandLM is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// RandLM is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with RandLM.  If not, see <http://www.gnu.org/licenses/>.
#include "LogFreqSketch.h"

namespace randlm {
  
  bool LogFreqSketch::count(const WordID* ngram, int len) {
    assert(false);
    return false;
  };
  
  bool LogFreqSketch::count(const WordID word, int start, int end) {
    assert(inserted_ < t_); // need space
    // compute bias in estimation (used to offset compounded bloom errors)
    if (inserted_ % (t_ >> 7) == 0) {
      float approx_rho = filter_->rho(1 << 10);
      // brhok = b(1-rho)^k
      // float brhok = pow(2.0, 1.0/info_->getValues())
      // * pow(1.0 - approx_rho, info_->getMisassign(end - start));
      // bias_ = b(1-rho)^k/(1 - b(1-rho)^k)
      // bias_ = brhok/(1.0 - brhok);
      float b = pow(2.0, 1.0/info_->getValues());
      float rhok = 1 - pow(1.0 - approx_rho, info_->getMisassign(end - start));
      bias_ = rhok / (1 - b * (1 - rhok));
      std::cerr << "Bias = " << bias_ << " (Rho = " << approx_rho << ")" << std::endl;
    }
    int max_idx;
    if (start < end) { // implies we have cached hashes
      max_idx = used_[RandLM::kMainEventIdx][end]; 
    } else {
      // unigram
      used_[RandLM::kMainEventIdx][end] = 0;
      max_idx = max_hashes_[RandLM::kMainEventIdx]; 
      uars_[end] = RandLMUtils::UniformAtRandom();
      ++observed_tokens_;
    }
    int i = 0;  // bits inserted on this 'count'
    int c = 0;  // bits read in the filter 
    bool newngram = false;
    while (i + c < max_idx) {
      // initialize for unigrams
      if (start == end)
	values_[RandLM::kMainEventIdx][end][i + c] = 0;
      double update_prob  = 1.0/(counts_[end - start][i + c + 1] * bias_ - counts_[end - start][c]);
      if (update_prob < uars_[end])
	break;
      hashes_[RandLM::kMainEventIdx][i + c]->increment(word, end - start, 
						       values_[RandLM::kMainEventIdx][end][i + c], 
						       &values_[RandLM::kMainEventIdx][end][i + c]);
      // if bit is found and none were missing so far then increment read bit
      if (i == 0 && filter_->testBit(values_[RandLM::kMainEventIdx][end][i + c])) {// % m_)) {
	++c;
      } else {
	// otherwise set new bit
	assert(filter_->setBit(values_[RandLM::kMainEventIdx][end][i + c])); // % m_));
	// if inserting a hash corresponding to the code = 0 indicate a new ngram
	newngram = newngram || (i + c) < alpha_[end - start];
	++i;
	++inserted_;
	// unless require multiple insertions for this increment break here
	if (update_prob < 1.0 + Quantiser::kFloatErr) 
	  break;
      }
    }  
    used_[RandLM::kMainEventIdx][end] = i + c;
    work_ += i + c;
    observations_++;
    return newngram;
  }
  void LogFreqSketch::printOnlineStats() {
    std::cerr << observations_ << "\t" << work_ << "\t"
	      << (observations_ > 0 ? static_cast<double>(work_) / static_cast<double>(observations_) : 0)
	      << std::endl;
  }
  bool LogFreqSketch::optimise(float working_mem) {
    // estimate space requirements that are provided expicitly for batch LogFreqBloomFilter
    assert(!optimised_);
    assert(info_ != NULL);
    assert(info_->hasFalsePosSpec()); // required
    assert(info_->hasMemorySpec());  // required as uppder bound
    assert(!info_->hasFalseNegSpec());  // can't have false neg
    // setup parameters from error spec
    assert(setParameters());
    // set maximum memory to working mem
    maximum_m_ = static_cast<uint64_t>(info_->getMemory() * (8.0*1024.0*1024.0));
    optimised_ = true;
    return true;
  }

  uint64_t LogFreqSketch::computeTotalHashes() {
    assert(maximum_m_ > 0);
    return static_cast<uint64_t>(ceil(maximum_m_ * log(2.0)));
  }

  bool LogFreqSketch::setupCache(int max_cache) {
    assert(max_cache_ == 0);  
    // initialise cache for parent
    assert(LogFreqBloomFilter::setupCache(max_cache));
    // setup extra storage for uars
    uars_ = new double[max_cache_];
    for (int i = 0; i < max_cache_; ++i)
      uars_[i] = 0;
    return true;
  }

  // TODO: take advantage of extra bits if redundancy from misassign > 1
  bool LogFreqSketch::assignCountMapping(LogQuantiser* log_quantiser){
    // setup mapping directly from hash functions to counts
    assert(optimised_ && log_quantiser != NULL);
    max_code_[RandLM::kMainEventIdx] = log_quantiser->getMaxCode();
    assert(setupFilter());
    assert(setupCache(Corpus::kMaxSentenceWords));  // requires large cache for 
    counts_ = new double*[order_];
    for(int i = 0; i < order_; ++i){
      counts_[i] = new double[max_hashes_[RandLM::kMainEventIdx]];
      for (int j = 0; j < max_hashes_[RandLM::kMainEventIdx]; ++j) {
	// hashes less than alpha don't correspond to a valid code (i.e. count = 0)
	counts_[i][j] = j < alpha_[i] ? 0 : log_quantiser->getValue( (j - alpha_[i]) / k_[i]);
	//if (j < 32)
	// std::cerr << counts_[i][j] << " ";
      }
      //      std::cerr << std::endl;
      // recompute if k > 1
      // TODO: for some reason this doesn't work ...
      /*
      if (k_[i] > 1) {
	for (int j = 0; j <  max_hashes_[RandLM::kMainEventIdx] - k_[i]; ++j) {
	  int offset = (j - alpha_[i]) % k_[i];
	  if (offset > 0 && j > alpha_[i]) 
	    if ( (counts_[i][j + k_[i] - offset] - counts_[i][j - offset]) > 1.0) {
	      // diff between two counts k apart
	      double incr = (counts_[i][j - offset] + counts_[i][j + k_[i] - offset]) /(float)k_[i];
	      counts_[i][j] = counts_[i][i] + (incr *  offset);
	    }
	if (j < 32)
	  std::cerr << counts_[i][j] << " ";
	}
	std::cerr << std::endl;
      }
      */
      

    }


    return true;
  }

  bool LogFreqSketch::load(RandLMFile* fin) {
    // just maximum m 
    return fin->read((char*)&maximum_m_, sizeof(maximum_m_));;
  }

  bool LogFreqSketch::save(RandLMFile* fout) {
    // save in reverse initialisation order
    assert(LogFreqBloomFilter::save(fout));  // saves RandLMStruct first
    assert(OnlineRandLMStruct::save(fout));
    // just maximum m
    return fout->write((char*)&maximum_m_, sizeof(maximum_m_));;
  }

}

