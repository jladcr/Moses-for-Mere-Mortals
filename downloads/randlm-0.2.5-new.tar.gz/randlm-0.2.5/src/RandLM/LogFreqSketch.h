// Copyright 2008 David Talbot
//
// This file is part of RandLM
//
// RandLM is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// RandLM is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with RandLM.  If not, see <http://www.gnu.org/licenses/>.
#ifndef INC_LOG_FREQ_SKETCH_H
#define INC_LOG_FREQ_SKETCH_H

#include "RandLMStruct.h"
#include "LogFreqBloomFilter.h"
#include "RandLMPreproc.h"

namespace randlm {

  // Online version of LogFreqBloomFilter that uses probabilistic
  // counting (Morris 1978) to build the data structure online.
  class LogFreqSketch : public LogFreqBloomFilter, OnlineRandLMStruct {
  public:
    LogFreqSketch(RandLMInfo* info) :  RandLMStruct(info), 
      LogFreqBloomFilter(info), OnlineRandLMStruct(info),
      maximum_m_(0), uars_(NULL), counts_(NULL), bias_(0.0),
      observations_(0), work_(0) {
      // check that estimator is prob counting
      assert(info->getEstimator() == RandLMStruct::kCoinTossingEstimationCode);
      // check that only storing counts
      assert(info->getEventType() == RandLMInfo::kCountEvent);
    }
    LogFreqSketch(RandLMInfo* info, RandLMFile* fin) 
      :  RandLMStruct(info, fin), LogFreqBloomFilter(info, fin), 
      OnlineRandLMStruct(info, fin), maximum_m_(0), 
      uars_(NULL), counts_(NULL) , bias_(0.0),
      observations_(0), work_(0) {
      // check that estimator is prob counting
      assert(info->getEstimator() == RandLMStruct::kCoinTossingEstimationCode);
      assert(info->getEventType() == RandLMInfo::kCountEvent);
      assert(load(fin));
    }
    ~LogFreqSketch() {
      delete[] uars_;
      if (counts_ != NULL)
	for (int i = 0; i < order_; ++i)
	  delete[] counts_[i];
      delete[] counts_;  // mapping directly from hash idx to count
    }
    bool optimise(float working_mem);
    // updates counts to reflect one observation of 'ngram' 
    bool count(const WordID* ngram, int len);
    bool count(const WordID word, int start, int end);
    bool save(RandLMFile* file);
    // return resized size used at run time
    uint64_t getSize() { return static_cast<uint64_t>(static_cast<float>(inserted_) / log(2.0)); }
    void printOnlineStats();
  protected:
    bool setupCache(int max_cache);
    bool assignCountMapping(LogQuantiser* log_quantiser);
    bool load(RandLMFile* fin);
    uint64_t computeTotalHashes();
    uint64_t maximum_m_;  // maximum memory used until finished 
    double* uars_;  // random samples used for approximate counting
    double** counts_;
    float bias_;
    uint64_t observations_;
    uint64_t work_;
  };
}

#endif  // INC_LOG_FREQ_SKETCH_H

