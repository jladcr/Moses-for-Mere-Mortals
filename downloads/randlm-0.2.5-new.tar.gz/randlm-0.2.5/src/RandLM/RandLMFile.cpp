// Copyright 2008 Abby Levenberg, David Talbot
//
// This file is part of RandLM
//
// RandLM is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// RandLM is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with RandLM.  If not, see <http://www.gnu.org/licenses/>.
#include <cstdlib>
#include "RandLMFile.h" 

namespace randlm {

  // RandLMFile class
  const std::string RandLMFile::kStdInDescriptor = "___stdin___";
  const std::string RandLMFile::kStdOutDescriptor = "___stdout___";
  // compression commands
  const FileExtension RandLMFile::kGzipped = ".gz";
  const FileExtension RandLMFile::kBzipped2 = ".bz2";

  const std::string RandLMFile::kCatCommand = "cat";
  const std::string RandLMFile::kGzipCommand = "gzip -f";
  const std::string RandLMFile::kGunzipCommand = "gunzip -f";
  const std::string RandLMFile::kBzip2Command = "bzip2 -f";
  const std::string RandLMFile::kBunzip2Command = "bunzip2 -f";
  
  RandLMFile::RandLMFile(const std::string & path, std::ios_base::openmode flags, bool checkExists)
    : std::fstream(NULL), path_(path), flags_(flags), buffer_(NULL), fp_(NULL) {  
    if( !(flags^(std::ios::in|std::ios::out)) ) {
      fprintf(stderr, "ERROR: RandLM does not support bidirectional files (%s).\n", path_.c_str());
      exit(EXIT_FAILURE);
    }
    else
    assert(setStreamBuffer(flags & std::ios::in));
    //this->precision(8);
  }

  RandLMFile::~RandLMFile() {
    if( fp_ != 0 ) 
      pclose(fp_);
    if( path_ != RandLMFile::kStdInDescriptor &&
        path_ != RandLMFile::kStdOutDescriptor )
      delete buffer_;
    if( this->is_open() ) 
      this->close();
  }
  
  fdstreambuf * RandLMFile::openCompressedFile(const char * cmd) {
    //bool isInput = (flags_ & std::ios::in);
    //open pipe to file with compression/decompression command
    const char * p_type = (flags_ & std::ios::in ? "r" : "w");
    fp_ = popen(cmd, p_type);
    if( fp_ == NULL ) {
      fprintf(stderr, "ERROR:Failed to open compressed file at %s\n", path_.c_str());
      exit(EXIT_FAILURE);
    }
    //open streambuf with file descriptor
    return new fdstreambuf(fileno(fp_));
  }

  bool RandLMFile::setStreamBuffer(bool checkExists) {
    // redirect stdin or stdout if necesary 
    if (path_ == RandLMFile::kStdInDescriptor) {
      assert(flags_ & std::ios::in);
      std::streambuf* sb = std::cin.rdbuf();
      buffer_ = sb;
    } else if (path_ == RandLMFile::kStdOutDescriptor) {
      assert(flags_ & std::ios::out);
      std::streambuf* sb = std::cout.rdbuf();
      buffer_ = sb;
    } else {
      // real file
      if( checkExists && ! fileExists() ) {
	fprintf(stderr, "ERROR: Failed to find file at %s\n", path_.c_str());
	exit(EXIT_FAILURE);
      }
      std::string cmd = "";
      if( isCompressedFile(cmd) && (! cmd.empty()) ) {
        buffer_ = openCompressedFile(cmd.c_str());
      } else {
	// open underlying filebuf 
	std::filebuf* fb = new std::filebuf(); 
	fb->open(path_.c_str(), flags_);
	buffer_ = fb;
      }
    }
    if (!buffer_) {
      fprintf(stderr, "ERROR:Failed to open file at %s\n", path_.c_str());
      exit(EXIT_FAILURE);
    }
    this->init(buffer_);
    return true;
  }
  
  /*
   * Checks for compression via file extension. Currently checks for 
   * ".gz" and ".bz2". 
   */ 
  bool RandLMFile::isCompressedFile(std::string & cmd)
  {
    bool compressed = false, isInput = (flags_ & std::ios::in);
    cmd = "";
    size_t len = path_.size();
    if( len > kGzipped.size()
	&& path_.find(kGzipped) == len - kGzipped.size()) {
      //gzip file command to compress or decompress
      compressed = true;
      //      cmd = (isInput ? "exec gunzip -cf " : "exec gzip -c > ") + path_;
      cmd = (isInput ? "exec " + kGunzipCommand + "c "
             : "exec " + kGzipCommand + "c > ") + path_;
    } else if( len > kBzipped2.size() && 
	       path_.find(kBzipped2) == len - kBzipped2.size()) {
      //do bzipped2 file command
      compressed = true;
      cmd = (isInput ? "exec " + kBunzip2Command + "c " 
             : "exec " + kBzip2Command + "c > ") + path_;
    } 
    return compressed;
  }
  
  bool RandLMFile::fileExists() {
    bool exists = false;
    struct stat f_info;
    if( stat(path_.c_str(), &f_info) == 0 ) //if stat() returns no errors
      exists = true;
    return( exists );
  }
 
  // static method used during preprocessing compressed files without
  // opening fstream objects.
  bool RandLMFile::getCompressionCmds(const std::string & filepath, std::string & compressionCmd,
				      std::string & decompressionCmd,
				      std::string & compressionSuffix) {
    // determine what compression and decompression cmds are suitable from filepath
    compressionCmd = kCatCommand;
    decompressionCmd = kCatCommand;
    if (filepath.length() > kGzipped.size() &&
	filepath.find(kGzipped) == filepath.length() 
	- kGzipped.length()) {
      compressionCmd = kGzipCommand;
      decompressionCmd = kGunzipCommand;
      compressionSuffix = kGzipped;
    } else if (filepath.length() > kBzipped2.size() &&
	       filepath.find(kBzipped2) == filepath.length() 
	       - kBzipped2.length() ) {
      compressionCmd = kBzip2Command;
      decompressionCmd = kBunzip2Command;
      compressionSuffix = kBzipped2;;
    }
    return (compressionCmd != kCatCommand && decompressionCmd != kCatCommand);
  }

  bool RandLMFile::reset() {
    // move to beginning of file
    if (fp_ != 0) {
      //can't seek on a pipe so reopen
      pclose(fp_);
      std::string cmd = "";
      if (isCompressedFile(cmd) && (!cmd.empty())) {
        buffer_ = openCompressedFile(cmd.c_str());

      } else {
	// open underlying filebuf
	std::filebuf* fb = new std::filebuf(); 
	fb->open(path_.c_str(), flags_);
	buffer_ = fb;
      }
    }
    this->init(buffer_);    
    buffer_->pubseekoff(0, std::ios_base::beg); //sets both get and put pointers to beginning of stream
    return true;
  }
} //end namespace
