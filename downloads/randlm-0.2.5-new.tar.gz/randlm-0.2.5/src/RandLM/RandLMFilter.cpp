// Copyright 2008 David Talbot
//
// This file is part of RandLM
//
// RandLM is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// RandLM is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with RandLM.  If not, see <http://www.gnu.org/licenses/>.
#include "RandLMFilter.h"

namespace randlm {

  // Write resized filter from file to avoid holding both in memory at same time
  bool ResizedBitFilter::resizeFromFile(RandLMFile* fin, uint64_t newaddresses) {
    // all the data < newsize will remain the same
    // determine rehashing parameters
    BitFilter oldfilter(fin, false);  // don't load data of old filter;
    old_addresses_ = oldfilter.getAddresses();
    uint64_t datastart = fin->tellg();
    int tries = 0;
    do {
      // reset this filter to zero
      reset();
      assert(newaddresses > 0 && newaddresses < oldfilter.getAddresses());
      a_ = 1 + RandLMUtils::Rand(newaddresses - 1) % (newaddresses - 1);
      b_ = RandLMUtils::Rand(newaddresses) % newaddresses;
      // read in old data and rehash/resize to newfilter
      uint64_t blocksize = 1 << 20; // blocks of  1MB
      uint8_t* blockdata = new uint8_t[blocksize];
      uint64_t index = 0;
      // following code relies on implementation details
      assert(cell_width_ == 8 && oldfilter.getCellWidth() == 8);
      assert(width_ == 1 && oldfilter.getWidth() == 1);
      // make sure at start of data
      assert(fin->seekg(datastart));
      while (index < oldfilter.getCells()) {
	uint64_t thisblock = (oldfilter.getCells() - index > blocksize) 
	  ? blocksize : oldfilter.getCells() - index;
	assert(fin->read((char*)blockdata, thisblock));
	// rehash/resize this block of data to newfilter
	for (uint64_t i = 0; i < thisblock; ++i)
	  for (int j = 7; j >= 0; --j)
	    if (blockdata[i] & 1 << j)
	      assert(setBit(j + ((index + i) << 3)));
	index += thisblock;
      }
      delete[] blockdata;
      std::cerr << rho() << std::endl;
      ++tries;
    } while (tries < 100 && (rho() < 0.48 || rho() > 0.55) );
    std::cerr << "Resized filter. Rho = " << rho() << std::endl;
    return true;
  }
}
