#include "RandLMFilter.h"
#include "RandLMFile.h"
#include <iostream>
#include <cmath>
#include <map>
#include <iterator>
using namespace randlm;

uint16_t mask(uint16_t value) {
  // determininist fingerprint function for testing
  return 0xfe ^ (value >> 8 | value << 8);
}

bool storeData(std::map<uint32_t, uint64_t> & data, CountingFilter<uint16_t>* f,
	       int addresses, int items, int width, bool counting, bool wrap_around, 
	       bool fingerprint, bool debug) {
  // generate random values that fit in address size and store in random locations
  for (int i = 0; i < items; ++i) {// addresses;  ++i) {
    uint64_t firstrand = rand();
    uint64_t secondrand = rand();
    uint16_t element = (firstrand | (secondrand << 32)) % (1ull << width); // 64bits random
    uint16_t fi = mask(element);
    if (counting)
      ++element;  // make sure not zero increment
    // get random location for write
    uint32_t loc = rand() % addresses; 
    if (debug) {
      std::cerr << (counting ? "adding : " : "writing : ")<<(int)element << " to location " << loc << std::endl;
      f->printFilter("before:");
    }
    if (counting) {
      for (uint64_t h = 0; h < element; ++h) {
	f->increment(loc);
	if (debug)
	  f->printFilter("during:");
      }
    } else {
      if (!fingerprint)
	f->write(loc, element);
      else
	f->writeWithFingerprint(loc, fi, element);
    }
    if (debug)
      f->printFilter(" after:");
    // store data for comparison
    if (data.count(loc) == 0)
      data[loc] = 0;
    if (counting) {
      if (wrap_around) // modulo arithmetic if wrap around counter
	data[loc] = (data[loc] + element) % (1ull << width); 
      else
	data[loc] = ((data[loc] + element) < ((1ull << width) - 1)) ? data[loc] + element : 
	  ((1ull << width) - 1);
    } else {
      data[loc] = element;
    }
  }
  return true;
} 

bool checkForErrors(std::map<uint32_t, uint64_t> & data, CountingFilter<uint16_t>* f,
		    int addresses, int items, int width, bool counting, bool wrap_around, 
		    bool fingerprint, bool debug) {
  int errors = 0;
  for (std::map<uint32_t, uint64_t>::iterator iter = data.begin(); iter!=data.end(); ++iter) {
    uint64_t correct = iter->second;
    uint16_t fi = mask(correct);
    uint16_t copy; 
    if (!fingerprint || counting)
      // pass in enough bytes to read address (bytes prior to 'first_byte' will stay zero
      f->read(iter->first, &copy);
    else
      f->readWithFingerprint(iter->first, fi, &copy);
    if ( (copy != correct) )
      ++errors;
    if (debug || copy != correct)
      std::cout << " wrote: " << (int)correct << " , retrieved : f[" << iter->first << "] = " 
		<< (int)copy << (copy != correct ? " ERROR" : "") << std::endl;
    if (copy != correct) {
      for (int i = 63; i >= 0; --i)
	if (copy & (1ull << i))
	  std::cout << 1;
	else
	  std::cout << 0;
      std::cout << std::endl;
    }
  }
  return errors == 0;
};


int testAll(int sr) {
  srand(sr);
  uint64_t addresses = 1000000;
  int items = 10000; // number of items to insert
  for (int fr = 1; fr >= 0; --fr) {
    std::cout << "Testing write with" << (!fr ? "out" : "") << " fingerprints... \n";
    for (int width = 1; width < 17; ++width) { 
      std::cout << " width = " << width << std::endl;
      std::map<uint32_t, uint64_t> data;
      CountingFilter<uint16_t> f(addresses, width, false);
      assert(storeData(data, &f, addresses, items, width, false, false, (bool)fr, false));
      RandLMFile out("test132", std::ios::out);
      f.save(&out);
      out.flush();
      out.close();
      RandLMFile fin("test132", std::ios::in);
      CountingFilter<uint16_t> f2(&fin);
      // check for errors on retrieval
      assert(checkForErrors(data, &f2, addresses, items, width, false, false, (bool)fr, false));
    }
    if (!(bool)fr) {
      std::cout << "Testing count with" << (!fr ? "out" : "") << " fingerprints... \n";
      for (int wr = 1; wr >=0; --wr) {
	std::cout << " wrap_around = " << wr << std::endl;
	for (int width = 1; width < 17; ++width) { 
	  std::cout << " width = " << width << std::endl;
	  std::map<uint32_t, uint64_t> data;
	  CountingFilter<uint16_t> f(addresses, width, (bool)wr);
	  assert(storeData(data, &f, addresses, items, width, true, (bool)wr, (bool)fr, false));
	  RandLMFile out("counttest132", std::ios::out);
	  f.save(&out);
	  out.flush();
	  out.close();
	  RandLMFile fin("counttest132", std::ios::in);
	  CountingFilter<uint16_t> f2(&fin);
	  // check for errors on retrieval
	  assert(checkForErrors(data, &f2, addresses, items, width, true, (bool)wr, (bool)fr, false));
	}
      }
    }
  }
  return 0;
}

int main(int argc, char** argv) {
  if (argc != 2 && argc != 9){
    std::cerr << "./filtertest <srand>\n";
    std::cerr << " or\n";
    std::cerr << "./filtertest <addresses> <width> <items> <counting> <wrap_around> <fingerprint> <debug> <srand>\n";
    exit(1);
  } 
  if (argc == 2)
    return testAll(atoi(argv[1]));
  // test routines for RandLMFilter
  uint64_t addresses = atoi(argv[1]);
  int width = atoi(argv[2]);
  // this is a constraint on the test routines that should really be removed 
  // the filter can have arbitrary sized addresses
  assert(width <= 64); 
  int items = atoi(argv[3]); // number of items to insert
  bool counting = atoi(argv[4]); // whether to test "increment" or "write" functionality
  bool wrap_around = atoi(argv[5]);  // whether counter wraps around
  bool fingerprint = atoi(argv[6]);  // whether to apply a fingerprint
  bool debug = atoi(argv[7]);
  srand(atoi(argv[8])); 
  std::cout << "addresses = " << addresses << " width = " << width 
	    << " items = " << items
	    << " counting = " << counting 
	    << " wrap_around = " << wrap_around  << " fingerprint = " << fingerprint
	    << " debug = " << debug << std::endl;
  // store correct data
  std::map<uint32_t, uint64_t> data;
  CountingFilter<uint16_t> f(addresses, width, wrap_around);
  assert(storeData(data, &f, addresses, items, width, counting, wrap_around, fingerprint, debug));
  // check for errors on retrieval
  assert(checkForErrors(data, &f, addresses, items, width, counting, wrap_around, fingerprint, debug));
  return 0;
};

