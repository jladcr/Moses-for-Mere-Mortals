// Copyright 2008 David Talbot
//
// This file is part of RandLM
//
// RandLM is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// RandLM is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with RandLM.  If not, see <http://www.gnu.org/licenses/>.
#ifndef INC_RANDLM_HASH_H
#define INC_RANDLM_HASH_H

#include <string>
#include <iostream>
#include <fstream>
#include <cassert>

#include "RandLMTypes.h"
#include "RandLMFile.h"
#include "RandLMUtils.h"

namespace randlm {

  // class UniversalHash: implements 2-wise universal hash function
  // (Carter & Wegman, 1979) suitable for sequences.
  template <typename T>
    class UniversalHash {
    public:
    UniversalHash(T m, int len = 1)
      : m_(m), len_(len) {
      // insist that range is prime
      assert(RandLMUtils::IsPrime(m));
      // instantiate random parameters
      a_ = new T[len_];
      b_ = new T[len_];
      for (int i = 0; i < len_; ++i) {
	a_[i] = 1 + static_cast<T>(RandLMUtils::Rand(m_));
	b_[i] = static_cast<T>(RandLMUtils::Rand(m_));
      }
    }
    UniversalHash(RandLMFile* fin) {
      assert(load(fin));
    }
    ~UniversalHash() { 
      delete[] a_;
      delete[] b_;
    }
    inline T increment(const WordID word, int pos, T prev_value) { 
      // get hash of ngram with 'word' added to left of previous call.
      return (prev_value + (a_[pos] * word) + b_[pos]); // % m_;
    }
    inline T increment(const WordID word, int pos, T prev_value, T* value) { 
      // get hash of ngram with 'word' added to left of previous call.
      *value = (prev_value + (a_[pos] * word) + b_[pos]);// % m_;
      return *value;
    }
    inline T hash(const WordID* ngram, int len) {
      // get hash of sequence of 'ngram'
      int pos = 0;
      T value = ((a_[pos] * ngram[len - 1]) + b_[pos]);// % m_;
      while (++pos < len)
	value = (value + (a_[pos] * ngram[len - 1 - pos]) + b_[pos]);// % m_;
      // return hash value for complete sequence
      return value; 
    }
    inline bool hash(const WordID* ngram, int len, T* value) {
      // get hash of sequence of 'ngram'
      int pos = 0;
      *value = ((a_[pos] * ngram[len - 1]) + b_[pos]);// % m_;
      while (++pos < len)
	*value = (*value + (a_[pos] * ngram[len - 1 - pos]) + b_[pos]);// % m_;
      // return hash value for complete sequence
      return true;
    }
    // i/o for hash parameters
    bool save(RandLMFile* out) {
      assert(out->write((char*)&len_, sizeof(len_)));
      assert(out->write((char*)&m_, sizeof(m_)));
      for (int i = 0; i < len_; ++i) {
	assert(out->write((char*)&a_[i], sizeof(a_[i])));
	assert(out->write((char*)&b_[i], sizeof(b_[i])));
      }
      return true;
    }
    bool load(RandLMFile* fin) {
      assert(fin->read((char*)&len_, sizeof(len_)));
      assert(fin->read((char*)&m_, sizeof(m_)));
      a_ = new T[len_];
      b_ = new T[len_];
      for (int i = 0; i < len_; ++i) {
	assert(fin->read((char*)&a_[i], sizeof(a_[i])));
	assert(fin->read((char*)&b_[i], sizeof(b_[i])));
      }
      return true;
    }
    T getRange() { return m_; }
    int getOrder() { return len_; }
    protected:
    T m_;  // range of hash function
    int len_;  // max sequence length that can be hashed
    T* a_;  // hash function parameters
    T* b_;
  };  

  /*
  // UnaryCountingHashSet wraps a set of UniversalHash functions and 
  // implements caching between calls (useful for unary counting schemes.)
  template<typename T>
    class UnaryCountingHashSet {
    public:
    UnaryCountingHashSet(int num_hashes, T m, int max_order, int max_sequence_len)
      : num_hashes_(num_hashes), m_(m), max_order_(max_order),
      max_sequence_len_(max_sequence_len) {
      assert(initHashes());
      assert(initCache());
    }
    UnaryCountingHashSet(RandLMFile* fin) {
      assert(loadHashes(fin));
      assert(initCache());
    }
    ~UnaryCountingHashSet() {
      for (int i = 0; i < num_hashes_; ++i)
	delete hashes_[i];
      delete[] hashes_;
      for (int i = 0; i < max_order_; ++i)
	delete[] cached_[i];
      delete[] cached_;
      for (int i = 0; i < max_sequence_len_; ++i)
	delete[] cached_values_[i];
      delete[] cached_values_;
    }
    bool hash(const WordID ngram, int len, int lastpos, T* value, bool first = false) {
      // get next hash for ngram of length 'len' ending at 'lastpos'
      if (first) {
	hash_idx_[lastpos] = 0;
	order_[lastpos] = 0;
      }
      if (hash_idx_ == num_hashes_)  // no more hashes
	return false;
      // start from scratch for unigrams
      if (order_ > 1) {
	// use cache if avaiable
	if (cached_[order_-2][lastpos_] >= hash_idx_)
	  // compute hash value incrementally
	  cached_values_[lastpos_][hash_idx_] = 
	    hashes_[hash_idx_]->increment(sequence_[lastpos_-(order_-1)], len_-order_,
					  cached_values_[lastpos_][hash_idx_]);
      } else {
	  // compute hash from scratch
	cached_values_[lastpos_][hash_idx_] = 
	  hashes_[hash_idx_]->hash(&sequence_[lastpos_-(order_-1)], order_);
      }
      ++cached_[order_-1][lastpos_];
      *value = cached_values_[lastpos_][hash_idx_];	
      ++hash_idx_;
      return true;
    }
    T hash(const WordID* sequence, int len, int index) {
      // no caching just hash whole sequence 
      return hashes_[index]->hash(&sequence, len);
    }
    bool setSequence(const WordID* ngram, int len) {
      // associate sequence with this set of hash functions
      sequence_ = ngram;
      len_ = len;
      return len <= max_sequence_;
    }
    protected:
    bool initHashes() {
      // instantiate new hash functions
      hashes_ = new UniversalHash<T>*[num_hashes_];
      for (int i = 0; i < num_hashes_; ++i)
	hashes_[i] = new UniversalHash<T>(m_, len_);
      return true;
    }
    bool initCache() {
      // set up structures for caching and maintaining state
      hash_idx_ = new int[max_sequence_];
      order_ = new int[max_sequence_];
      values_ = new int*[max_sequence_];
      for (int i = 0; i < max_sequence_; ++i) {
	hash_idx_[i] = 0;
	order_[i] = 0;
	values_[i] = new int[num_hashes_];
	for (int j = 0; j < num_hashes_; ++j)
	  values_[i][j] = 0;
      }
      return true;
    }
    bool loadHashes(RandLMFile* fin) {
      // load parameters 
      assert(fin->read((char*)num_hashes_, sizeof(num_hashes_)));
      assert(fin->read((char*)m_, sizeof(m_)));
      assert(fin->read((char*)max_order_, sizeof(max_order_)));
      assert(fin->read((char*)max_sequence_, sizeof(max_sequence_)));
      // load hash functions
      hashes_ = new UniversalHash<T>*[num_hashes_];
      for (int i = 0; i < num_hashes_; ++i) {
	hashes_[i] = new UniversalHash<T>(fin);
	assert(hashes_[i]->getRange() == m_);
	assert(hashes_[i]->getOrder() == len_);
      }
      return initCache();
    }
    bool saveHashes(RandLMFile* fout) {
      // save parameters to file
      assert(fout->write((char*)num_hashes_, sizeof(num_hashes_)));
      assert(fout->write((char*)m_, sizeof(m_)));
      assert(fout->write((char*)max_order_, sizeof(max_order_)));
      assert(fout->write((char*)max_sequence_, sizeof(max_sequence_)));
      // save hash functions
      for (int i = 0; i < num_hashes_; ++i)
	hashes_[i]->save(fout);
    }
    UniversalHash<T>** hashes_;  // array of hash functions
    int** values_;  // cached values for these positions
    T m_;  // size of all hash functions
    int max_order_; // max lenght of any ngram for any hash function
    int num_hashes_;  // number of hash functions in set
    int max_sequence_; // max number of distinct ngrams to be hashed separately
    // current state variables
    WordID* sequence_; // local pointer to current sequence
    int len_; // length of current sequence
    int* hash_idx_;  // index of hash function for given position
    int* order_;  // order of ngram for given position
  };
  */

} // ends namespace

#endif //INC_RANDLM_HASH_H
