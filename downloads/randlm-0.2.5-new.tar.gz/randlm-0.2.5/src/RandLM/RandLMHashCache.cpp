// Copyright 2008 David Talbot
//
// This file is part of RandLM
//
// RandLM is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// RandLM is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with RandLM.  If not, see <http://www.gnu.org/licenses/>.
#include "RandLMHashCache.h"

namespace randlm {
  
  bool RandLMHashCache::check(const WordID* ngram, int len, float* log_prob, const void** state) {
    // check enough space
    if (index_ + len > max_size_) {
      loaded_ = false;
      return false;
    }
    // copy ngram to end of ngrams_ buffer
    for (int i = 0; i < len - 1; ++i)
      ngrams_[index_ + i] = ngram[i];
    // set high bit of last word id
    ngrams_[index_ + len - 1] = ngram[len - 1] | (1ull << 31);
    loaded_ = true;
    // search hash map for ngram
    NgramCacheIter cacheIter = cache_.find(&ngrams_[index_]);
    if (cacheIter == cache_.end()) {
      // insert empty data into cache and increment buffer
      cache_[&ngrams_[index_]] = ngramdata();
      index_ += len;
      return false;
    }
    // get cached data
    *log_prob = cacheIter->second.log_prob;
    *state = cacheIter->second.state;

    return true;
  }
  
  bool RandLMHashCache::clearCache() {
    cache_.clear();
    index_ = 0;
    std::cerr << "Cleared hash map cache." << std::endl;
    return true;
  }
  
  bool RandLMHashCache::store(int len, float log_prob, const void* state) {
    // stores last checked ngram in cache
    assert(loaded_);  // must have been loaded previously
    NgramCacheIter cacheIter = cache_.find(&ngrams_[index_ - len]);
    assert(cacheIter != cache_.end());  // fails if not already stored
    cacheIter->second.log_prob = log_prob;
    cacheIter->second.state = state;
    loaded_ = false;
    return true;
  }

}
