// Copyright 2008 David Talbot
//
// This file is part of RandLM
//
// RandLM is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// RandLM is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with RandLM.  If not, see <http://www.gnu.org/licenses/>.

#include <ext/hash_map>
#include <ext/hash_set>
#include <iostream>
#include <cassert>
#include "RandLMTypes.h"

namespace randlm {

  struct ngramdata {
    float log_prob;  // log prob of ngram
    const void* state;  // pointer to longest bo context
  };

  struct ngramhash {
    // hash function
    int operator()(const WordID* ngram) const {
      int h = 0;
      while ((*ngram & (1ull << 31)) == 0)
        h += __gnu_cxx::hash<int>()(*ngram++);
      return h + __gnu_cxx::hash<int>()(*ngram);
    }    
    // equality operator
    bool operator()(const WordID* ngram, const WordID* ngram2) const {
      while (*ngram == *ngram2) {
	if ((*ngram & (1ull << 31)) != 0)
	  return true;
	++ngram;
	++ngram2;
      }
      return false;
    }
  };
  
  typedef __gnu_cxx::hash_map<const WordID*, ngramdata, ngramhash, ngramhash> NgramCache;
  typedef NgramCache::iterator NgramCacheIter;

  class RandLMHashCache {
  public:
    RandLMHashCache(int max_size, int order) 
      : max_size_(max_size) {
      cache_.resize(max_size / order);  // assume queries are all for max order
      ngrams_ = new WordID[max_size + 1];
      assert(ngrams_ != NULL);
      index_ = 0;
    }
    ~RandLMHashCache() { delete ngrams_; }
    bool check(const WordID* ngram, int len, float* log_prob, const void** state);
    bool store(int len, float log_prob, const void* state);
    bool clearCache();
    bool full() { return !loaded_; } // if failed to load ngram then must be full
  private:
    int max_size_;
    NgramCache cache_; // hash map from ngrams to cached data
    WordID* ngrams_; // holds distinct ngrams
    int index_;
    bool loaded_;
  };

}
