// Copyright 2008 David Talbot
//
// This file is part of RandLM
//
// RandLM is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// RandLM is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with RandLM.  If not, see <http://www.gnu.org/licenses/>.
#ifndef INC_RANDLM_INFO_H
#define INC_RANDLM_INFO_H

#include "RandLMFile.h"
#include "RandLMUtils.h"
#include "RandLMTypes.h"

namespace randlm {
  // class RandLMInfo: holds metadata for a RandLM 
  
  // RandLMInfo is written out as header when writing
  // a RandLM to file.

  // NOTE: error probability and some other parameters in RandLMInfo 
  // are assumed to be on a log-scale: e.g. max_count = log(max_count);
  // false_pos_ = log(1/fp) etc.

  // The optional parameter 'order' taken by the setter methods
  // assigns to parameters for length 'order' up to 'max_order_'.

  class RandLMInfo {
  public:
    static const int kCountBit = 0;
    static const int kLogProbBit = 1;
    static const int kBackoffWeightBit = 2;
    static const int kHistoryBit = 3;

    // EventType specifies the type of event being quantified for an ngram.
    static const EventType kNullEvent = 0;

    static const EventType kCountEvent = 1 << 0;
    static const EventType kHistoryEvent = 1 << 1;  
    static const EventType kLogProbEvent = 1 << 2;
    static const EventType kBackoffWeightEvent = 1 << 3;
    // composite events 
    static const EventType kAnyCountEvent = (1 << 0) | (1 << 1);
    static const EventType kAnyProbEvent = (1 << 2) | (1 << 3);

    // string descriptors
    static const std::string kNullEventName;;

    static const std::string kCountEventName;
    static const std::string kHistoryEventName;  
    static const std::string kLogProbEventName;
    static const std::string kBackoffWeightEventName;
    // composite events 
    static const std::string kAnyCountEventName;
    static const std::string kAnyProbEventName;
    
    static std::string getEventName(EventType event);
    static int getNumEvents(EventType event);

    RandLMInfo(int max_order, StructCode struct_type, EventType events, float values, float memory, 
	       float max_count, Smoothing scheme, float smoothing_param, Estimator estimator, 
	       bool order_specific) 
      : max_order_(max_order), struct_type_(struct_type), events_(events),
      values_(values), memory_(memory), max_count_(max_count), scheme_(scheme), 
      smoothing_param_(smoothing_param), estimator_(estimator), order_specific_(order_specific),
      cache_size_(50){
      assert(init());
    }
    RandLMInfo(RandLMFile* fin) {
      assert(load(fin));
      cache_size_ = 50;
    }
    ~RandLMInfo() {}
    bool init() {
      // set up structures for error rates
      false_pos_.clear();
      false_neg_.clear();
      misassign_.clear();
      fail_prob_.clear();
      for (int i = 0; i < max_order_; ++i) {
	false_pos_.push_back(0);
	false_neg_.push_back(0);
	misassign_.push_back(0);
	fail_prob_.push_back(0);
      }
      return true;
    }
    bool isOrderSpecific() { return order_specific_; }
    // check if parameterised for these criteria
    bool hasFalsePosSpec() { return false_pos_[0] > 0; }
    bool hasFalseNegSpec() { return false_neg_[0] > 0; }
    bool hasMisassignSpec() { return misassign_[0] > 0; }
    bool hasFailProbSpec() { return fail_prob_[0] > 0; }
    bool hasMemorySpec() { return memory_ > 0; }
    // accessor methods
    int getMaxOrder() { return max_order_; }
    StructCode getStructType() { return struct_type_; }
    EventType getEventType() { return events_; }
    bool storesEvent(EventType events) { return (events & events_) == events; }
    Smoothing getSmoothingScheme() { return scheme_; }
    float getSmoothingParam() { return smoothing_param_; }
    void setSmoothingParam(float param) { smoothing_param_ = param; }
    float getEstimator() { return estimator_; }
    void setCacheSize(int memory) {
      assert(memory > 0);
      cache_size_ = memory;
    }
    int getCacheSize() { return cache_size_; }
    // when retrieving error rates etc. we can ignore whether 
    // the params are order specific since all were set regardless.
    float getFalsePos(int order = 0) {
      order = std::max(0, order - 1);
      assert(order >= 0 && order < max_order_);
      return false_pos_[order];
    }
    float getFalseNeg(int order = 0) {
      order = std::max(0, order - 1);  
      assert(order >= 0 && order < max_order_);
      return false_neg_[order];
    }
    float getMisassign(int order = 0) {
      order = std::max(0, order - 1);  
      assert(order >= 0 && order < max_order_);
      return misassign_[order];
    }
    float getFailProb(int order = 0) {
      order = std::max(0, order - 1);  
      assert(order >= 0 && order < max_order_);
      return fail_prob_[order];
    }
    float getMaxCount() {
      return  max_count_;
    }
    float getValues() {
      return values_;
    }
    float getMemory() { return memory_; }
    // set methods set parameters for 'order' to 'max_order'
    // (i.e. called for order = 1 they set all values
    // so don't call in descending order!)
    void setFalsePos(float rate, int order = 1) { 
      // can't have zero false positive rate
      assert(order_specific_ || order == 1);
      assert(order > 0 && order <= max_order_);
      assert(rate > 0);
      // set this and all higher ngrams to this value
      for (int i = order - 1; i < max_order_; ++i)
	false_pos_[i] = rate;
    }
    void setFalseNeg(float rate, int order = 1) { 
      assert(order_specific_ || order == 1);
      assert(order > 0 && order <= max_order_);
      assert(rate >= 0);
      for (int i = order - 1; i < max_order_; ++i)
	  false_neg_[i] = rate;
    }
    void setMisassign(float rate, int order = 1) { 
      assert(order_specific_ || order == 1);
      assert(order > 0 && order <= max_order_);
      assert(rate >= 0);
      for (int i = order - 1; i < max_order_; ++i)
	misassign_[i] = rate;
    }
    void setFailProb(float prob, int order = 1) { 
      assert(order_specific_ || order == 1);
      assert(order > 0 && order <= max_order_);
      assert(prob >= 0);
      for (int i = order - 1; i < max_order_; ++i)
	  fail_prob_[i] = prob;
    }
    // check that two infos are the same
    bool equals(RandLMInfo* info) {
      assert(info != NULL);
      if(! (info->isOrderSpecific() == order_specific_ &&
	    info->getMaxOrder() == max_order_ &&
	    info->getStructType() == struct_type_ &&
	    info->getEventType() == events_) )
	return false;
      // check error rates
      for (int i = 0; i < max_order_; ++i)
	if (! (info->getFalsePos(i+1) == false_pos_[i] && 
	       info->getFalseNeg(i+1) == false_neg_[i] && 
	       info->getMisassign(i+1) == misassign_[i] &&
	       info->getFailProb(i+1) == fail_prob_[i]) )
	  return false;
      return info->getValues() == values_ && 
	info->getMaxCount() == max_count_ && info->getMemory() == memory_;
    }
    // i/o functions
    bool save(RandLMFile* out) {
      assert(out != NULL);
      // save all parameters
      assert(out->write((char*)&max_order_, sizeof(max_order_)));
      assert(out->write((char*)&struct_type_, sizeof(struct_type_)));
      assert(out->write((char*)&events_, sizeof(events_)));
      assert(out->write((char*)&values_, sizeof(values_)));
      assert(out->write((char*)&memory_, sizeof(memory_)));
      assert(out->write((char*)&max_count_, sizeof(max_count_)));
      assert(out->write((char*)&scheme_, sizeof(scheme_)));
      assert(out->write((char*)&smoothing_param_, sizeof(smoothing_param_)));
      assert(out->write((char*)&estimator_, sizeof(estimator_)));
      assert(out->write((char*)&order_specific_, sizeof(order_specific_)));
      for (int i = 0; i < max_order_; ++i) {
	assert(out->write((char*)&false_pos_[i], sizeof(false_pos_[i])));
	assert(out->write((char*)&false_neg_[i], sizeof(false_neg_[i])));
	assert(out->write((char*)&misassign_[i], sizeof(misassign_[i])));
	assert(out->write((char*)&fail_prob_[i], sizeof(fail_prob_[i])));
      }
      return true;
    }
  private:
    bool load(RandLMFile* fin) {
      assert(fin != NULL);
      // load parameters
      assert(fin->read((char*)&max_order_, sizeof(max_order_)));
      assert(fin->read((char*)&struct_type_, sizeof(struct_type_)));
      assert(fin->read((char*)&events_, sizeof(events_)));
      assert(fin->read((char*)&values_, sizeof(values_)));
      assert(fin->read((char*)&memory_, sizeof(memory_)));
      assert(fin->read((char*)&max_count_, sizeof(max_count_)));
      assert(fin->read((char*)&scheme_, sizeof(scheme_)));
      assert(fin->read((char*)&smoothing_param_, sizeof(smoothing_param_)));
      assert(fin->read((char*)&estimator_, sizeof(estimator_)));
      assert(fin->read((char*)&order_specific_, sizeof(order_specific_)));
      // set up structures for error rates
      assert(init());
      for (int i = 0; i < max_order_; ++i) {
	assert(fin->read((char*)&false_pos_[i], sizeof(false_pos_[i])));
	assert(fin->read((char*)&false_neg_[i], sizeof(false_neg_[i])));
	assert(fin->read((char*)&misassign_[i], sizeof(misassign_[i])));
	assert(fin->read((char*)&fail_prob_[i], sizeof(fail_prob_[i])));
      }
      return true;
    }
    int max_order_;  // maximum length of sequences stored
    StructCode struct_type_;  // type of randomised data structure
    EventType events_; // type of event(s) stored by model
    float values_;  // log range of values or log-base for quantisation
    float memory_;  // total megabytes
    float max_count_; // max log count
    Smoothing scheme_;  // smoothing scheme used
    float smoothing_param_; // free parameter for smoothing scheme 
    Estimator estimator_; // estimation scheme used
    bool order_specific_;  // whether error parameters are specific to each ngram length
    int cache_size_; 
    std::vector<float> false_pos_;
    std::vector<float> false_neg_;
    std::vector<float> misassign_;
    std::vector<float> fail_prob_;
  };
  
} // ends namespace

#endif  // INC_RANDLM_INFO_H
