// Copyright 2008 Abby Levenberg, David Talbot
//
// This file is part of RandLM
//
// RandLM is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// RandLM is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with RandLM.  If not, see <http://www.gnu.org/licenses/>.
#include "RandLMParams.h"
#include "RandLMInfo.h"
#include "RandLMPreproc.h"
#include <iterator>

namespace randlm {
  // initalize static containers 
  std::map<std::string, std::string> RandLMParams::abbrev_names_;
  std::set<std::string> RandLMParams::valid_names_;
  std::map<std::string, std::set<std::pair<std::string, std::string > > > RandLMParams::poss_values_;

  // parameter constants
  const std::string RandLMParams::kNotValidParamName = "__NOT_VALID_NAME__";  // invalid param
  const std::string RandLMParams::kNotSetValue = "__NOT_SET__";
  const std::string RandLMParams::kListedValuesAllowed = "__various_values__";
  // simple value types
  const std::string RandLMParams::kBoolValue = "__bool_value__"; 
  const std::string RandLMParams::kIntValue = "__int_value__";
  const std::string RandLMParams::kFloatValue = "__float_value__";
  const std::string RandLMParams::kAnyValue = "__any_value__";  // any string
  
  const std::string RandLMParams::kTrueValue = "1";
  const std::string RandLMParams::kFalseValue = "0";

  RandLMParams::RandLMParams() {
    assert(allStaticItemsInitiated());
  }
  
  RandLMParams::RandLMParams(int argc, char ** argv) {
    assert(allStaticItemsInitiated());
    loadParams(argc, argv);
  }

  bool RandLMParams::loadParams(int argc, char ** argv) {
    // load params from commandline args
    //if( argc < 3 ) {
    //  fprintf(stderr, "ERROR: No parameters. Use \"-config\" or \"-f\" to specify configuration file.\n");
    //  return false;
    //}
    bool load_from_file = false;
    int jumpBy = 0;
    for( int i = 1; i < argc; i += jumpBy ) {
      std::string param = argv[i];
      RandLMUtils::trim(param, "- ");
      // normalise parameter to long name
      param = normaliseParamName(param);
      //if the parameter is of type booL no corresponding value
      if( getValueType(param) == kBoolValue ) {
        jumpBy = 1;
        if(!setParamValue(param, kTrueValue)) {
          fprintf(stderr, "\tInvalid Param: (%s)\n", param.c_str());
          printHelp(param);
          return false;
        }
      } else { //not of type bool so must have corresponding value
        assert(i+1 < argc);
        jumpBy = 2;
        std::string val = argv[i+1];
        RandLMUtils::trim(val);
        if( param == "config" )
          load_from_file = true;      
        if(!setParamValue(param, val)) {
          fprintf(stderr, "\tInvalid Param: (%s, %s)\n", param.c_str(), val.c_str());
          printHelp(param);
          return false;
        }
      }
    }
    bool success = true;
    // load from file if specified
    if (load_from_file)
      success = loadParams(getParamValue("config"));
    printParams(); 
    return success;
  }
  
  bool RandLMParams::loadParams(const std::string & file_path) {
    // parameters loaded from file don't override cmd line paramters
    fprintf(stderr, "Loading Parameters...\n");
    fprintf(stderr, "\tconfigFile: %s\n", file_path.c_str());
    RandLMFile file(file_path.c_str(), std::ios::in);
    std::string line, param;
    while ( getline(file, line) ) {
      RandLMUtils::trim(line);
      //ignore comments (lines beginning with '#') and empty lines
      if( line[0] == '#' || line.empty() ) continue;
      if( line[0] == '[' ) {
	RandLMUtils::trim(line, "-[]"); //remove brackets
	// normalise parameter names
	param = normaliseParamName(line);
        //handle boolean type parameters
        if( getValueType(param) == kBoolValue ) {
          if( checkParamIsSet(param) || setParamValue(param, kTrueValue) ) { 
            fprintf(stderr, "\t%s: %s\n", param.c_str(), getParamValue(param).c_str());
          } else {
            fprintf(stderr, "\tInvalid Param: (%s, %s)\n", param.c_str(), line.c_str());
            return false;
          }
        }
      } else {
	// setParamValue only called for parameters that aren't already set
        // TODO: verify that this works as intended
	if( checkParamIsSet(param) || setParamValue(param, line) ) { 
	  fprintf(stderr, "\t%s: %s\n", param.c_str(), getParamValue(param).c_str());
	} else {
	  fprintf(stderr, "\tInvalid Param: (%s, %s)\n", param.c_str(), line.c_str());
	  return false;
	}
      }
    }
    return true;
  }

  bool RandLMParams::setParamValue(const std::string& name, const std::string& val) {
    bool set = isValidParamSetting(name, val);
    if( set ) 
      RandLMParams::params_[name] = val;  
    return( set );
  }

  std::string RandLMParams::getParamValue(const std::string & name) const {
    // Find value for name or return null value. All parameter names
    // are normalised when read from cmdline or file so no need
    // to check if name is an abbreviation.
    if( isValidParamName(name) )
      if( params_.find(name) != params_.end() )
	return (params_.find(name)->second);
    // return false value for boolean values that are not specified
    return (getValueType(name) == kBoolValue) ? kFalseValue : kNotSetValue; 
  }

  int RandLMParams::getVectorParamValues(const std::string & name, std::vector<std::string> & values) const {
    // get param values(s) may be more than one separated by commas
    values.clear();
    if( isValidParamName(name) )
      if( params_.find(name) != params_.end() )
	return RandLMUtils::tokenizeToStr(params_.find(name)->second.c_str(), values, ",");
    return 0;
  }

  bool RandLMParams::getParamValue(const std::string & name, std::string & value) const {
    // Find value for name or set value to null string and return value != null
    // return true but with value = kFalseValue if boolean parameter 
    value = kNotSetValue;
    if( isValidParamName(name) ) {
      if( params_.find(name) != params_.end() )
	 value = (params_.find(name)->second);
      else if (getValueType(name) == kBoolValue)
	value = kFalseValue;
    }
    return value != kNotSetValue;
  }
  
  std::string RandLMParams::normaliseParamName(const std::string & name) const {
    // Map valid abbreviations to long names. Retain other names.
    return (abbrev_names_.find(name) != abbrev_names_.end()) ? 
      (abbrev_names_.find(name)->second) : name;
  }
  
  bool RandLMParams::isValidParamName(const std::string & name) {
    return valid_names_.find(name) != valid_names_.end(); 
  }
  
  bool RandLMParams::isValidParamSetting(const std::string& name, const std::string & val) {
    // check name is correct
    std::map<std::string, std::set<std::pair<std::string, std::string> > >::const_iterator mit;
    mit = poss_values_.find(name); 
    if (mit == poss_values_.end())  // no such parameter name
      return false;
    // check whether restricted string values or numeric constants are roughly right
    std::set<std::pair<std::string, std::string> >::const_iterator sit = mit->second.begin(); 
    std::string digitsplus = "0123456789.,-";
    // any non-null value
    if (sit->first == kAnyValue)
      return val.length() > 0;
    // numeric values
    if (sit->first == kBoolValue || 
       sit->first == kIntValue ||
       sit->first == kFloatValue)
      return (val.find_first_not_of(digitsplus,0) == std::string::npos);  // not robust
    else  // check for specific string
      for (;sit != mit->second.end(); ++sit)
	if (sit->first == val)
	  return true;
    return false;
  }
  
  void RandLMParams::initValidParamNames() {
    // only includes full parameter names not abbreviations.
    // required parameters used by BuildRandLM
    valid_names_.insert("order");              // n-gram model order
    valid_names_.insert("struct");             // randomised data structure to use
    valid_names_.insert("values");          // log of max number of distinct values or log base if counts
    // One of memory or falsepos required if both are set k is used and memory is treated as an upper bound.
    // memory/falsepos are specified either once for all n-grams, or once per n-gram order.
    valid_names_.insert("memory");             // total megabytes used (at runtime)
    valid_names_.insert("falsepos");           // log (1/falsepos) (i.e. k^+)
    valid_names_.insert("falseneg");           // log (1/falseneg) (i.e. k^-)
    valid_names_.insert("misassign");          // log (1/misassign) (i.e. k^*)
    valid_names_.insert("failprob");          // log (1/delta) 
    valid_names_.insert("maxcount");           // log of max count if online 
    valid_names_.insert("count-cut-off");      // minimum count to include in model
    // i/o parameters
    valid_names_.insert("input-path");         // input filename(s)
    valid_names_.insert("input-type");         // input data type 
    valid_names_.insert("test-path");         // input filename(s)
    valid_names_.insert("test-type");         // input data type 
    valid_names_.insert("vocab-path");         // vocabulary for input data
    valid_names_.insert("stats-path");         // path to file of counts of values
    valid_names_.insert("word-count");          // corpus size in tokens
    // boolean flags specifying detailed formatting of input 
    valid_names_.insert("integerised");        // input converted to uint32 (requires vocab)
    valid_names_.insert("normalised");         // normalised formatting
    valid_names_.insert("sorted-by-ngram");    // input sorted by ngram (only used if vocab is supplied) 
    valid_names_.insert("sorted-by-value");    // input sorted by value
    valid_names_.insert("reversed-ngrams");    // input ngrams are in reverse order
    valid_names_.insert("estimator");         // method to use for estimating counts
    // output details
    valid_names_.insert("output-prefix");      // output file prefix
    valid_names_.insert("output-dir");         // output directory
    valid_names_.insert("output-type"); 
    valid_names_.insert("output-integerised"); 
    valid_names_.insert("output-normalised"); 
    valid_names_.insert("output-reversed-ngrams"); 
    valid_names_.insert("output-sorted-by-ngram"); 
    valid_names_.insert("output-sorted-by-value"); 
    valid_names_.insert("keep-tmp-files");           // delete intermediate files as soon as possible
    valid_names_.insert("add-bos-eos");
    // optional parameters 
    valid_names_.insert("working-mem");        // working space (in megabytes) defaults to m
    valid_names_.insert("config");             // config file path
    valid_names_.insert("tmp-dir");            // temporary directory
    // optional struct specific parameters
    valid_names_.insert("smoothing");          // smoothing scheme to use (with count based structs)
    valid_names_.insert("smoothing-param");    // float parameter used by smoothing scheme 
    // parameters required by QueryRandLM
    valid_names_.insert("randlm");             // path to previously constructed randlm
    valid_names_.insert("checks");             // level of checks to apply during lookup
    valid_names_.insert("get-counts");         // retrieve counts (from CountRandLM)
    valid_names_.insert("seed");         // srand seed
  }
  
  void RandLMParams::initAbbrevParamNames() {
    abbrev_names_["n"] = "order";
    abbrev_names_["s"] = "struct";
    abbrev_names_["v"] = "values";
    abbrev_names_["m"] = "memory";
    abbrev_names_["k"] = "falsepos";
    abbrev_names_["in"] = "input-path";
    abbrev_names_["in-type"]  = "input-type";
    abbrev_names_["vcb"] = "vocab-path";
    abbrev_names_["wc"] = "word-count";
    abbrev_names_["out-dir"] = "output-dir";
    abbrev_names_["out-pref"] = "output-prefix";
    abbrev_names_["out-type"] = "output-type";
    abbrev_names_["keep"] = "keep-tmp-files";
    abbrev_names_["w"] = "working-mem";
    abbrev_names_["f"] = "config";
    abbrev_names_["sch"] = "smoothing";
    abbrev_names_["r"] = "randlm";
    abbrev_names_["tmp"] = "tmp-dir";
  }
 
  void RandLMParams::initPossibleParamValues() {
    // specify possible values for each parameter (using constants for bool, int and float types)
    // Format: map<name, set< pair<value, description> > > (all strings)
    // i.e. named parameter can take one value from set
    // set up structures
    for (std::set<std::string>::iterator it = valid_names_.begin(); it != valid_names_.end(); ++it)
      poss_values_[*it] = std::set<std::pair<std::string, std::string> >();
    // insert possible values here for each parameter
    poss_values_["order"].insert(std::make_pair(kIntValue,"n-gram model order"));
    poss_values_["struct"].insert(std::make_pair(RandLMStruct::kLogFreqBloomFilter, "Description goes here..."));
    poss_values_["struct"].insert(std::make_pair(RandLMStruct::kLogFreqSketch, ""));
    poss_values_["struct"].insert(std::make_pair(RandLMStruct::kLossyDict, ""));
    poss_values_["struct"].insert(std::make_pair(RandLMStruct::kBloomierFilter,""));
    poss_values_["struct"].insert(std::make_pair(RandLMStruct::kBloomMap,""));
    poss_values_["struct"].insert(std::make_pair(RandLMStruct::kCountMinSketch,""));
    poss_values_["values"].insert(std::make_pair(kFloatValue,
						 "Max number of distinct values associated"
						 " with n-grams if arbitrary values. Log base"
						 " for quantisation if storing counts."));
    poss_values_["maxcount"].insert(std::make_pair(kFloatValue,
						   "Log of max count stored by online structures."));
    poss_values_["memory"].insert(std::make_pair(kFloatValue,"Number of megabytes used by"
						 " randlm. (If \'falsepos\' is also specified"
						 " then this value is only an upper bound."));
    poss_values_["falsepos"].insert(std::make_pair(kFloatValue,
						   "log of inverse false positive rate"
						   " = log 1/false_pos_rate (also used for"
						   " log of inverse expected error rate"
						   " when appropriate."));
    poss_values_["falseneg"].insert(std::make_pair(kFloatValue,
						   "log of inverse false negative rate"
						   " = log 1/false_neg_rate."));
    poss_values_["misassign"].insert(std::make_pair(kFloatValue,
						    "log of inverse misassignment rate"
						    " = log 1/misassignment_rate."));
    poss_values_["failprob"].insert(std::make_pair(kFloatValue,
						    "log of inverse failure prob"
						    " = log 1/fail_prob."));
    poss_values_["count-cut-off"].insert(std::make_pair(kIntValue,
							"minimum count ngram included in model."));
    
    poss_values_["input-path"].insert(std::make_pair(kAnyValue,"Path to input data."));
    poss_values_["test-path"].insert(std::make_pair(kAnyValue,"Path to test data."));
    poss_values_["input-type"].insert(std::make_pair(InputData::kCorpusFileType,"Tokenised corpus with one"
						     " sentence per line. <s> and </s> markers will"
						     " automatically be added."));
    poss_values_["input-type"].insert(std::make_pair(InputData::kCountFileType,"Ngram counts with"
						     " one <count, ngram> pair per line and the count"
						     " as the first token on each line."));
    poss_values_["input-type"].insert(std::make_pair(InputData::kArpaFileType,"Standard Arpa model file."));
    poss_values_["input-type"].insert(std::make_pair(InputData::kBackoffModelFileType,"Ngram file with"
						     " <value, ngram> pair per line where <value> can"
						     " be parsed into two valid floats: <logprob, backoff>."));
    poss_values_["test-type"].insert(std::make_pair(InputData::kNgramsFileType,"Ngrams one per line."));
    poss_values_["test-type"].insert(std::make_pair(InputData::kCorpusFileType,"Tokenised corpus with one"
						     " sentence per line. <s> and </s> markers will"
						     " automatically be added."));


    poss_values_["vocab-path"].insert(std::make_pair(kAnyValue,"Path to vocab file."
						     " Implies that the data has already been"
						     " converted to integers."));
    poss_values_["stats-path"].insert(std::make_pair(kAnyValue,"Path to statistics (i.e. counts of values)"
						     " file."));
    poss_values_["word-count"].insert(std::make_pair(kIntValue,"Number of tokens in corpus."));
    poss_values_["seed"].insert(std::make_pair(kIntValue,"Random number generator seed."));
    poss_values_["normalised"].insert(std::make_pair(kBoolValue,"Whether input data"
						     " is ngrams with value at start of line."));
    poss_values_["integerised"].insert(std::make_pair(kBoolValue,"Whether input data"
							  " has been converted to uint32s."));
    poss_values_["sorted-by-ngram"].insert(std::make_pair(kBoolValue,"Whether input data"
							  " has been sorted by ngram (assumes input is"
							  " already converted to WordIDs hence requires"
							  " \'vocab\' to be specified)."));
    poss_values_["sorted-by-value"].insert(std::make_pair(kBoolValue,"Whether input data"
							  " has been sorted by value."));
    poss_values_["reversed-ngrams"].insert(std::make_pair(kBoolValue,"Whether input data"
							  " has had ngrams reversed."));
    poss_values_["estimator"].insert(std::make_pair(RandLMStruct::kBatchEstimation,
						    "Generate counts first then store."));
    poss_values_["estimator"].insert(std::make_pair(RandLMStruct::kOnlineEstimation,
						    "Estimate directly from corpus."));
    poss_values_["estimator"].insert(std::make_pair(RandLMStruct::kCoinTossingEstimation,
						    "Estimate from corpus using prob counting."));
    poss_values_["output-prefix"].insert(std::make_pair(kAnyValue,"Prefix for output files."));
    poss_values_["output-dir"].insert(std::make_pair(kAnyValue,"Directory for output."));
    poss_values_["output-type"].insert(std::make_pair(RandLM::kRandLMFileType, "Full RandLM."));
    poss_values_["output-type"].insert(std::make_pair(InputData::kCountFileType, "Ngram count file."));
    poss_values_["output-type"].insert(std::make_pair(InputData::kCorpusFileType, "Corpus data."));
    poss_values_["output-type"].insert(std::make_pair(InputData::kBackoffModelFileType, "Backoff model."));
    poss_values_["output-integerised"].insert(std::make_pair(kBoolValue,"Whether output data"
							     " should be mapped to integers."));
    poss_values_["output-normalised"].insert(std::make_pair(kBoolValue,"Whether output data"
							    " should be in normalisd form: "
							    "one ngram + one value per line."));
    poss_values_["output-reversed-ngrams"].insert(std::make_pair(kBoolValue,"Whether output data"
						" should have ngrams in reverse order: A B C -> C B A."));
    poss_values_["output-sorted-by-ngram"].insert(std::make_pair(kBoolValue,"Whether output data"
								 " should be sorted by ngram."));
    poss_values_["output-sorted-by-value"].insert(std::make_pair(kBoolValue,"Whether output data"
								 " should be sorted by value."));
    poss_values_["add-bos-eos"].insert(std::make_pair(kBoolValue,
						      "Whether to add <s> </s>."));
    poss_values_["keep-tmp-files"].insert(std::make_pair(kBoolValue,
							 "Whether to delete intermediate files or not."));
    poss_values_["working-mem"].insert(std::make_pair(kFloatValue,
						      "Amount of memory in MB available while building LM."));
    poss_values_["config"].insert(std::make_pair(kAnyValue,"Path to configuration file."));
    poss_values_["tmp-dir"].insert(std::make_pair(kAnyValue,"Temporary directory."));
    poss_values_["smoothing"].insert(std::make_pair(RandLM::kStupidBackoffSmoothing,
						    "Stupid backoff smoothing."));
    poss_values_["smoothing"].insert(std::make_pair(RandLM::kWittenBellSmoothing,
						    "WittenBell method C smoothing."));
    poss_values_["smoothing"].insert(std::make_pair(RandLM::kBackoffSmoothing,
						    "ARPA style backoff."));
    poss_values_["smoothing-param"].insert(std::make_pair(kFloatValue,
							  "Free parameter in smoothing scheme"
							  " e.g. backoff penalty in stupid backoff."));
    poss_values_["randlm"].insert(std::make_pair(kAnyValue,"Path to existing randlm."));
    poss_values_["checks"].insert(std::make_pair(kIntValue,"Level of checks to apply: 0 = none, "
						 "1 = standard, 2 = all"));
    poss_values_["get-counts"].insert(std::make_pair(kBoolValue,"Whether to retrieve counts rather than"
						     " probabilities (only works with a CountRandLM)."));
  }
  
  bool RandLMParams::checkParamIsSet(const std::string & name) const {
    // Returns true for non-bool parameter that is set to anything.
    // Returns true for bool parameter only if set to true.
    if (getValueType(name) == kBoolValue)  // boolean value so check whether true
      return getParamValue(name) == kTrueValue;
    return (getParamValue(name) != kNotSetValue);
  }
  
  std::string RandLMParams::getValueType(const std::string & name) const {
    // determine value type
    if (poss_values_.find(name) == poss_values_.end())
      return kNotValidParamName;  // invalid param name so none
    // multiple specific values listed
    if ((poss_values_.find(name))->second.size() > 1) 
      return kListedValuesAllowed;  
    // must have a single specific value (i.e. one of constants above)
    return ((poss_values_.find(name))->second.begin())->first;
  }

  bool RandLMParams::checkAllSet(const ParamSet & names) const {
    // check that all required params are set
    for (ParamSet::const_iterator it = names.begin(); it != names.end(); ++it)
      if (!checkParamIsSet(*it)) {
	std::cerr << "\'" << *it << "\' not set!" << std::endl;
	return false;
      }
    return true;
  }

  bool RandLMParams::checkExactlyOneSet(const ParamSet & names) const {
    // check that exactly one of these parameters is set
    bool one_set = false;
    for (ParamSet::const_iterator it = names.begin(); it != names.end(); ++it)
      if (checkParamIsSet(*it) && one_set)
	return false;
      else
	one_set = true;
    return one_set;
  }

  bool RandLMParams::checkNoneSet(const ParamSet & names) const {
    // check that all params are not set
    for (ParamSet::const_iterator it = names.begin(); it != names.end(); ++it)
      if (checkParamIsSet(*it))
	return false;
    return true;
  }

  int RandLMParams::getParamCount() const {
    return params_.size();
  }
  
  bool RandLMParams::printHelp(const std::string & name) {
    // print help for this parameter
    std::cerr << "Parameter \'" << name << "\'";
    if (poss_values_.find(name) != poss_values_.end()) {
      std::cerr << " can take the following values:" << std::endl;
      std::set<std::pair<std::string, std::string> >::iterator it;
      for (it = poss_values_[name].begin(); it != poss_values_[name].end(); ++it)
	std::cerr << "\t\'"<< it->first << "\'\t(" << it->second << ")\n";
    } else {
      std::cerr << " is not recognized.\n";
    }
    return true;
  }
  
  bool RandLMParams::printParams() {
    // print out parameters and values
    std::map<std::string, std::string>::iterator it;
    std::cerr << "User defined parameter settings:\n";
    for (it = params_.begin(); it != params_.end(); ++it)
      std::cerr << "\t" << it->first << "\t" << it->second << "\n";
    return true;
  }

  void RandLMParams::init() {
    initValidParamNames();
    initAbbrevParamNames();
    initPossibleParamValues(); 
  }
  
  bool RandLMParams::allStaticItemsInitiated() {
    //crude check that returns false if any static containers
    //are of size zero.
    return( abbrev_names_.size() && valid_names_.size() 
            && poss_values_.size() );
  }

} // ends namespace
