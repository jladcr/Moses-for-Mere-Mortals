// Copyright 2008 Abby Levenberg, David Talbot
//
// This file is part of RandLM
//
// RandLM is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// RandLM is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with RandLM.  If not, see <http://www.gnu.org/licenses/>.
#ifndef INC_RANDLM_PARAMS_H
#define INC_RANDLM_PARAMS_H

#include <iostream>
#include <map>
#include <set>
#include <cassert>
#include "RandLMFile.h"
#include "RandLMStruct.h"

namespace randlm {
  
  // Abbreviations supported but all parameters are normalised to long names
  // as soon as they are read from cmd line or file.
  typedef std::set<std::string> ParamSet;
  typedef std::map<std::string, std::string> ParamMap;
  typedef std::set<std::string> ValueSet;

  class RandLMParams {
  public:
    static const std::string kNotSetValue; 
    static const std::string kNotValidParamName;
    static const std::string kListedValuesAllowed;

    static const std::string kBoolValue;
    static const std::string kIntValue;
    static const std::string kFloatValue;
    static const std::string kAnyValue;

    static const std::string kFalseValue;
    static const std::string kTrueValue;
    
    RandLMParams();
    RandLMParams(int argc, char** argv);
    ~RandLMParams() {}
    bool loadParams(int argc, char ** argv);
    bool loadParams(const std::string& param_file);
    bool setParamValue(const std::string& name, const std::string& value); 
    int getVectorParamValues(const std::string & name, std::vector<std::string> & values) const;
    std::string getParamValue(const std::string& name) const;
    bool getParamValue(const std::string& name, std::string & value) const;
    std::string getValueType(const std::string & name) const;
    bool checkParamIsSet(const std::string& name) const;
    bool checkAllSet(const ParamSet & names) const;
    bool checkExactlyOneSet(const ParamSet & names) const;
    bool checkNoneSet(const ParamSet & names) const;
    int getParamCount() const;
    bool printParams();
    static bool printHelp(const std::string & name);
    static bool isValidParamName(const std::string & name);
    static bool isValidParamSetting(const std::string & name, const std::string & value);
    static void init();
  private:
    static void initValidParamNames();
    static void initAbbrevParamNames();
    static void initPossibleParamValues();
    static bool allStaticItemsInitiated();
    std::string normaliseParamName(const std::string &name) const;
    std::map<std::string, std::string> params_;  // name/value parameter strings
    static std::map<std::string, std::string> abbrev_names_;  // abbrev->long names
    static std::set<std::string> valid_names_;  // all valid param names
    // descriptions of possible values for each parameter
    static std::map<std::string, std::set<std::pair<std::string, std::string> > > poss_values_;  
  };
  
} // ends namespace

#endif //INC_RANDLM_PARAMS.H
