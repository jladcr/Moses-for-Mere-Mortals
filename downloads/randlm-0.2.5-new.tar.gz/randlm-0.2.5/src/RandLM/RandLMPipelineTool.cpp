// Copyright 2008 David Talbot
//
// This file is part of RandLM
//
// RandLM is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// RandLM is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with RandLM.  If not, see <http://www.gnu.org/licenses/>.
#include "RandLMPipelineTool.h"

namespace randlm {

  const std::string RandLMPipelineTool::kPipelineTool = "PipelineTool";
  
  bool RandLMPipelineTool::getPipeline(Pipeline*& pipeline) {
    // pass ownership of pipline to caller
    assert(pipeline_ != NULL);  // check we have something to give back
    pipeline = pipeline_;
    pipeline_ = NULL; // relinquish
    return true;
  }

  bool RandLMPipelineTool::setRequirements() {
    // set up parameter requirements for any pipeline (basically file handling)
    // keep minimal since subclasses cannot remove them
    setRequire("order");
    setRequire("input-path");
    setRequire("input-type");
    setRequire("output-prefix");
    setRequire("output-dir");
    // vocab-path is required if 'integerised' data
    setRequire("vocab-path", "integerised");
    // require working-mem and tmp-dir
    setRequire("working-mem");
    setRequire("tmp-dir");
    return true;
  }

  bool RandLMPipelineTool::setDefaultValues() {
    // set up defaults for any pipline tool (subclasses may NOT override these).
    setDefault("order", "3");  // most common n-gram order
    setDefault("tmp-dir", "/tmp");
    setDefault("input-path", RandLMFile::kStdInDescriptor); // stdin 
    setDefault("input-type", InputData::kCorpusFileType);  // plain corpus
    setDefault("working-mem","100");  // MBs
    setDefault("output-dir", "."); 
    setDefault("output-prefix", "model");
    setDefault("add-bos-eos", RandLMParams::kTrueValue, "input-type", InputData::kCorpusFileType);
    setDefault("normalised", RandLMParams::kTrueValue, "input-type", InputData::kCountFileType);
    setDefault("normalised", RandLMParams::kTrueValue, "input-type", InputData::kBackoffModelFileType);
    setDefault("seed", "0");
    return true;
  }

  bool RandLMPipelineTool::setupPipeline() {
    // determine the correct form of InputData to instantiate based on params
    // and also create / load statistics and vocab objects
    srand(RandLMUtils::StringToInt(params_->getParamValue("seed")));
    std::string input_path = params_->getParamValue("input-path");
    std::string input_type = params_->getParamValue("input-type");
    std::string tmp_dir = params_->getParamValue("tmp-dir");
    std::string output_prefix = params_->getParamValue("output-prefix");
    std::string output_dir = params_->getParamValue("output-dir");
    float working_mem = RandLMUtils::StringToFloat(params_->getParamValue("working-mem"));
    int order = RandLMUtils::StringToInt(params_->getParamValue("order"));
    bool clean_up = !(RandLMUtils::StringToBool(params_->getParamValue("keep-tmp-files")));
    // parse input formatting booleans into a single uint8 Format
    Format format = static_cast<Format>(
	 (RandLMUtils::StringToBool(params_->getParamValue("normalised")) << InputData::kNormalisedBit) |
	 (RandLMUtils::StringToBool(params_->getParamValue("integerised")) << InputData::kIntegerisedBit) |
	 (RandLMUtils::StringToBool(params_->getParamValue("sorted-by-ngram")) << InputData::kSortedByNgramBit) |
	 (RandLMUtils::StringToBool(params_->getParamValue("sorted-by-value")) << InputData::kSortedByValueBit) |
	 (RandLMUtils::StringToBool(params_->getParamValue("reversed-ngrams"))<< InputData::kReversedNgramsBit));
    // instantiate a vocab to associate with the pipeline (may be read from file).
    Vocab* vocab = new Vocab();
    // if integerised we require a vocab path
    if (format & InputData::kIntegerisedFormat)
      assert(vocab->load(params_->getParamValue("vocab-path")));
    // instantiate a stats object to store counts of distinct (raw) values.
    Stats* stats = NULL;
    assert(Stats::initStats(input_type, order, stats));
    // try to load from file if available
    if (params_->checkParamIsSet("stats-path"))
      assert(stats->load(params_->getParamValue("stats-path")));
    // check for wc 
    if (params_->checkParamIsSet("word-count"))
      assert(stats->setTokenStats(RandLMUtils::StringToUint64(params_->getParamValue("word-count"))));
    // instantiate the correct form of input data 
    InputData* input_data = NULL;
    if (input_type == InputData::kCorpusFileType)
      input_data = new Corpus(input_path, input_type, tmp_dir, output_prefix, output_dir,
			      working_mem, order, clean_up, format, vocab, stats,
			      RandLMUtils::StringToBool(params_->getParamValue("add-bos-eos")));
    else if (input_type == InputData::kCountFileType)
      input_data = new CountFile(input_path, input_type, tmp_dir, output_prefix, output_dir,
				 working_mem, order, clean_up, format, vocab, stats);
    else if (input_type == InputData::kArpaFileType)
      input_data = new ArpaFile(input_path, input_type, tmp_dir, output_prefix, output_dir,
				working_mem, order, clean_up, format, vocab, stats);
    else if (input_type == InputData::kBackoffModelFileType)
      input_data = new BackoffModelFile(input_path, input_type, tmp_dir, output_prefix, output_dir,
					working_mem, order, clean_up, format, vocab, stats);
    assert(input_data != NULL);
    // pipeline will take ownership of vocab and input data
    pipeline_ = new Pipeline(input_data, vocab, stats);
    return (pipeline_ != NULL);
  }
}
