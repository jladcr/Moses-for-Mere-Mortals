// Copyright 2008 David Talbot
//
// This file is part of RandLM
//
// RandLM is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// RandLM is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with RandLM.  If not, see <http://www.gnu.org/licenses/>.
#ifndef RANDLM_PIPELINE_TOOL_H
#define RANDLM_PIPELINE_TOOL_H

#include "RandLMPipeline.h"
#include "RandLMTool.h"

namespace randlm {
  
  // Abstract class for command line tools that process 
  // some some InputData via a Pipeline.
  
  // Checks for and sets up file handling from cmd line parameters

  class RandLMPipelineTool : public RandLMTool {
  public:
    const static std::string kPipelineTool;
    RandLMPipelineTool(RandLMParams* params) : RandLMTool(params) {
      pipeline_ = NULL;      
      // check parameters for pipeline are present
      assert(checkParams(kPipelineTool));  // see RandLMTools
      // sets up input files pipeline
      assert(setupPipeline());
    }
    virtual ~RandLMPipelineTool() { delete pipeline_;}
    // preprocess must be called by any subclass to make sure data
    // is in the correct format.
    virtual bool preprocess() = 0;  
    // access data after it's been processed by pipeline
    bool getPipeline(Pipeline*& pipeline);
  protected:
    bool setRequirements();  // specified cmd line parameter constraints
    bool setDefaultValues();  // use defaults if none provided
    bool setupPipeline();  // sets up pipeline on basis of cmd line params
    bool validConversion();  // checks conversion can be performed by pipeline
    Format getInputFormat();  // determine formatting (as specified by cmd line parameters)
    Pipeline* pipeline_;
  };
  
}

#endif // RANDLM_PIPELINE_TOOL_H
