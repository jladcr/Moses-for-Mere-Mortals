#include "RandLMPreprocessor.h"

namespace randlm {
  
  const std::string RandLMPreprocessor::kPreprocessor = "Preprocessor";
 
  bool RandLMPreprocessor::setRequirements() {
    // requirements are all instantiated in parent 
    // disallow construction of RandLM (only do preprocessing).
    setRequire("output-type");
    setDisallow("struct");
    setDisallowValue("output-type", RandLM::kRandLMFileType);
    return true;
  }

  bool RandLMPreprocessor::setDefaultValues() {
    // assuming unspecified formatting booleans are all false (no need to specify). 
    setDefault("output-type", InputData::kCountFileType);
    return true;
  }

  bool RandLMPreprocessor::preprocess() {
    // uses parameters directly from cmd line
    Format outputFormat = static_cast<Format>(
     (RandLMUtils::StringToBool(params_->getParamValue("output-normalised")) << InputData::kNormalisedBit) |
     (RandLMUtils::StringToBool(params_->getParamValue("output-integerised")) << InputData::kIntegerisedBit) |
 (RandLMUtils::StringToBool(params_->getParamValue("output-sorted-by-ngram")) << InputData::kSortedByNgramBit) |
 (RandLMUtils::StringToBool(params_->getParamValue("output-sorted-by-value")) << InputData::kSortedByValueBit) |
 (RandLMUtils::StringToBool(params_->getParamValue("output-reversed-ngrams"))<< InputData::kReversedNgramsBit));
    // preprocess data to output type and format 
    return pipeline_->preprocess(params_->getParamValue("output-type"), outputFormat);
  }
}
