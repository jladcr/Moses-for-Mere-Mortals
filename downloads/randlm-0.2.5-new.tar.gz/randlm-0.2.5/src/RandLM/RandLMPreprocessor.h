#ifndef RANDLM_PREPROCESSOR_H
#define RANDLM_PREPROCESSOR_H

#include "RandLMParams.h"
#include "RandLMPipelineTool.h"

namespace randlm {
  
  // RandLMPreprocessor is a command line tool to perform
  // preprocessing prior to construction of a RandLM.
  
  class RandLMPreprocessor : public RandLMPipelineTool {
  public:
    const static std::string kPreprocessor;
    RandLMPreprocessor(RandLMParams* params) : RandLMPipelineTool(params) {
      // check parameters for preprocessing tool
      assert(checkParams(kPreprocessor));  
    }
    ~RandLMPreprocessor() {}
    // implementation just passes control directly to pipeline  
    virtual bool preprocess();  
  protected:
    bool setRequirements();
    bool setDefaultValues();
  };
  
}

#endif // INC_RANDLM_PREPROCESSOR_H
