// Copyright 2008 David Talbot
//
// This file is part of RandLM
//
// RandLM is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// RandLM is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with RandLM.  If not, see <http://www.gnu.org/licenses/>.
#include <cmath>
#include <vector>
#include <iterator>
#include <list>
#include <algorithm>
#include "RandLMQuantiser.h"
#include "RandLMStats.h"
#include "RandLMPreproc.h"

namespace randlm {

  const float Quantiser::kFloatErr;

  bool UniformQuantiser::computeCodeBook(Stats* stats) {
    // check that it is ONE of the following two events (not both)
    assert(event_type_ == RandLMInfo::kLogProbEvent ||
	   event_type_ == RandLMInfo::kBackoffWeightEvent);
    assert(stats != NULL && stats->hasNgramStats()
	   && stats->hasStatsFor(event_type_));
    // uniform quantiser requires stats to be estimated
    // check we can store this range of values
    assert(info_->getValues() < 32); // signed int codes
    // get all the distinct values interpreting as logprob or backoff weight
    FloatCounts counts;
    assert(stats->getCounts(counts, event_type_));
    std::list<float> distinct_values;
    for (FloatCounts::iterator iter = counts.begin(); 
	 iter != counts.end(); ++iter)
      distinct_values.push_back(iter->first); // dont need the frequencies
    // make sure unique values (... should be already)
    distinct_values.sort();
    distinct_values.unique();
    // if values = 0 then no quantisation
    std::vector<float> code_to_value_vec;
    int idx = 0;
    if (info_->getValues() > 0) {
      // split values into bins with same num of distinct values (ie. probs or bo weights) and average
      max_code_ = (static_cast<int>(pow(2.0, info_->getValues())) - 1);
      // get min and max value of statistics
      min_value_ = distinct_values.front() - Quantiser::kFloatErr;
      max_value_ = distinct_values.back() + Quantiser::kFloatErr;
      // determine number of values per code
      int values_per_code = 1; 
      int totalvalues = distinct_values.size();
      while ( (totalvalues + values_per_code - 1) / values_per_code > max_code_ + 1)
	++values_per_code;
      float bin_total = 0.0;
      int bin_size = 0;
      while (!distinct_values.empty()) {
	bin_total += distinct_values.front();
	distinct_values.pop_front();
	++bin_size;
	// final code 'max_code' may have more samples
	if (bin_size == values_per_code || distinct_values.empty()) {
	  // set code as average of bucket
	  code_to_value_vec.push_back(bin_total/static_cast<float>(bin_size));
	  // check valid logprob values
	  if (event_type_ == RandLMInfo::kLogProbEvent) 
	    assert(code_to_value_vec.back() < 0);
	  bin_size = 0;
	  bin_total = 0.0;
	  ++idx;
	}
      }
    } else {
      max_code_ = distinct_values.size() - 1;
      // get min and max value of statistics
      min_value_ = distinct_values.front() - Quantiser::kFloatErr;
      max_value_ = distinct_values.back() + Quantiser::kFloatErr;
      while (!distinct_values.empty()) {
	code_to_value_vec.push_back(distinct_values.front());
	distinct_values.pop_front();
	++idx;
      }
    }
    // truncate unused codes at top of range
    assert(idx <= max_code_ + 1);
    max_code_ = idx - 1;
    code_to_value_ = new float[max_code_ + 1];
    while (code_to_value_vec.size() > 0) {
      code_to_value_[idx-1] = code_to_value_vec.back();
      code_to_value_vec.pop_back();
      --idx;
    }
    std::cerr << "Computed codebook for " << RandLMInfo::getEventName(event_type_) 
	      << " (size = " << max_code_ + 1 << ")" << std::endl;
    assert(idx == 0);
    return true;
  }
  int UniformQuantiser::getCode(float value) {
    // binary search over codebook
    if ((value < min_value_ || value > max_value_)) {
      std::cerr << value << " " << min_value_ << " " << max_value_ << std::endl;
    }
    assert(!(value < min_value_ || value > max_value_));
    // determine index of first entry that is equal or greater than  'value'
    return static_cast<int>(std::lower_bound(code_to_value_, code_to_value_ + max_code_, value)
			    - code_to_value_);
  }
  bool UniformQuantiser::save(RandLMFile* out) {
    assert(out != NULL && Quantiser::save(out));
    std::cerr << "Saved uniform codebook with " << max_code_ + 1 << " codes." <<std::endl;
    return true;
  }
  bool UniformQuantiser::load(RandLMFile* fin) {
    assert(fin != NULL);
    std::cerr << "Loaded uniform codebook with " << max_code_ + 1<< " codes." <<std::endl;
    return true;
  }
  
  bool LogQuantiser::computeCodeBook(Stats* stats) {
    // compute the appropriate log_base_const_ used to transform counts
    assert(event_type_ & RandLMInfo::kAnyCountEvent);
    assert(stats != NULL && (stats->hasNgramStats() || stats->hasTokenStats())
	   && stats->hasStatsFor(event_type_));
    std::cerr << "Computing codebook for " << RandLMInfo::getEventName(event_type_);
    // use base <= 0 to mean no quantisation
    log_base_ = info_->getValues() > 0 ? pow(2.0, 1.0/info_->getValues()) : 0;  // take b = 2^{1/values}
    std::cerr << " (base = " << log_base_ << ") ";
    if (log_base_ > 0) {
      //log_base_ = info_->getValues();
      assert(log_base_ > 1); // otherwise infinite codes
      // compute reverse quantisation mapping
      max_code_ = 0;
      float value = 1; // code = 0 -> value = 1 for any base
      std::vector<float> code_to_value_vec;
      while (log(value)/log(2.0) < info_->getMaxCount()) {
	code_to_value_vec.push_back(value);  
	value = pow(log_base_, ++max_code_);      
      }
      code_to_value_vec.push_back(value);  // store max_code_ so in total [0, max_code_]
      // get valid range
      max_value_ = code_to_value_vec[max_code_];
      min_value_ = 1;
      // store codes in array for lookup
      code_to_value_ = new float[max_code_ + 1];
      code_to_log_value_ = new float[max_code_ + 1];
      for (int j = 0; j <= max_code_; ++j) {
	// map to integers
	code_to_value_[j] = floor(kFloatErr + code_to_value_vec[j]); //
	code_to_log_value_[j] = log10(code_to_value_[j]); // log_base 10 to match srilm
      }
      std::cerr << " (size = " << max_code_ + 1 << ")" << std::endl;
    } else { // identity mapping
      FloatCounts counts;
      assert(stats->getCounts(counts, event_type_));
      std::list<float> distinct_values;
      for (FloatCounts::iterator iter = counts.begin(); 
	   iter != counts.end(); ++iter)
	distinct_values.push_back(iter->first); // dont need the frequencies
      // make sure unique values (... should be already)
      distinct_values.sort();
      distinct_values.unique();
      max_code_ = distinct_values.size() - 1;
      // get min and max value of statistics
      min_value_ = distinct_values.front() - Quantiser::kFloatErr;
      max_value_ = distinct_values.back() + Quantiser::kFloatErr;
      code_to_value_ = new float[max_code_ + 1];
      code_to_log_value_ = new float[max_code_ + 1];
      for (int i = 0; i <= max_code_; ++i) {
	code_to_value_[i] = distinct_values.front();
	code_to_log_value_[i] = log10(code_to_value_[i]); // log_base 10 to match srilm
	distinct_values.pop_front();
      }
    }
    return true;
  }  
  int LogQuantiser::getCode(float value) {
    // should just be: return log_b(value)
    assert(!(value < min_value_ || value > max_value_));
    // but binary search removes errors due to floor operator above 
    int code =  static_cast<int>(std::lower_bound(code_to_value_, code_to_value_+ max_code_, 
						  value) - code_to_value_);
    // make sure not overestimating 
    code = code_to_value_[code] > value ? code - 1 : code;
    return code;
  }
  bool LogQuantiser::load(RandLMFile* fin) {
    assert(fin != NULL);
    assert(fin->read((char*)&log_base_, sizeof(log_base_)));
    code_to_log_value_ = new float[max_code_ + 1];
    for (int j = 0; j <= max_code_; ++j)
      assert(fin->read((char*)&code_to_log_value_[j], sizeof(code_to_log_value_[j])));
    std::cerr << "Loaded log codebook with " << max_code_ + 1 << " codes." <<std::endl;
    return true;
  }
  bool LogQuantiser::save(RandLMFile* out) {
    assert(out != NULL && Quantiser::save(out));
    assert(out->write((char*)&log_base_, sizeof(log_base_)));
    for (int j = 0; j <= max_code_; ++j) {
      assert(out->write((char*)&code_to_log_value_[j], sizeof(code_to_log_value_[j])));
    }
    std::cerr << "Saved log codebook with " << max_code_ + 1 << " codes." <<std::endl;
    return true;
  }
}
