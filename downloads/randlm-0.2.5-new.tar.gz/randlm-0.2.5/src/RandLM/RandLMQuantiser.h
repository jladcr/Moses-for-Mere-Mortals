// Copyright 2008 David Talbot
//
// This file is part of RandLM
//
// RandLM is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// RandLM is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with RandLM.  If not, see <http://www.gnu.org/licenses/>.
#ifndef INC_RANDLM_QUANTIZER_H
#define INC_RANDLM_QUANTIZER_H

#include "RandLMTypes.h"
#include "RandLMFile.h"
#include "RandLMInfo.h"

// classes for quantising counts and logprob/backoff weights
 
// Requires Stats object containing "counts of values" 
// and RandLMInfo object specifying quantisation parameters

namespace randlm {

  // Abstract base class for quantisers
  
  // Implementations map either counts OR logprobs OR backoff weights
  // to integer codes and back again.
  // class UniformQuantiser quantises logprobs OR backoff weights 
  // class LogQuantiser can quantises counts
  class Stats;
  
  class Quantiser {
  public:
    static const float kFloatErr = 0.00001f;

    Quantiser(RandLMInfo* info, Stats* stats, EventType event) 
      : info_(info), event_type_(event), code_to_value_(NULL),
      max_code_(0), max_value_(0), min_value_(0) {
      // make info is okay and that some type of event are being quantised
      assert(info != NULL);
      assert(info->getEventType() & event);
    }
    Quantiser(RandLMInfo* info, RandLMFile* fin, EventType event) :
      info_(info), event_type_(event), code_to_value_(NULL), 
      max_code_(0), max_value_(0), min_value_(0) {
      assert(info != NULL && info->getEventType() & event);
      assert(load(fin,event));
    }
    virtual ~Quantiser() {     
      delete[] code_to_value_;
    }
    // generate quantiser for this value type (must be compatible with info/stats)
    virtual bool computeCodeBook(Stats* stats) = 0;
    bool canQuantise(EventType event) { return event_type_ & event; }
    // mapping functions may be order specific
    virtual int getCode(float value) = 0; 
    int getMaxCode() { return max_code_; }  
    inline float getValue(int code) {
      // table look up for all quantisers 
      return code_to_value_[code];
    }
    virtual bool save(RandLMFile* out) {
      assert(out->write((char*)&event_type_, sizeof(event_type_)));
      assert(out->write((char*)&max_code_, sizeof(max_code_)));
      assert(out->write((char*)&max_value_, sizeof(max_value_)));
      assert(out->write((char*)&min_value_, sizeof(min_value_)));
      for (int j = 0; j <= max_code_; ++j)
	assert(out->write((char*)&code_to_value_[j], sizeof(code_to_value_[j])));
      return true;
    }
  protected:
    // i/o
    bool load(RandLMFile* fin, EventType event) {
      assert(fin != NULL);
      assert(fin->read((char*)&event_type_, sizeof(event_type_)));
      // check we've loaded the correct quantiser
      assert(event_type_ == event);
      assert(fin->read((char*)&max_code_, sizeof(max_code_)));
      assert(fin->read((char*)&max_value_, sizeof(max_value_)));
      assert(fin->read((char*)&min_value_, sizeof(min_value_)));
      code_to_value_ = new float[max_code_ + 1];
      for (int j = 0; j <= max_code_; ++j)
	assert(fin->read((char*)&code_to_value_[j], sizeof(code_to_value_[j])));
      return true;
    }
    RandLMInfo* info_;  // local pointer to info containing error parameters etc.
    EventType event_type_;  // type of statistics being quantised
    float* code_to_value_; 
    int max_code_; 
    float max_value_;
    float min_value_;
  };

  // Uniform quantiser suitable for backoff log probs and weights 
  // bins distinct probabilities such that same number of distinct values in each bin
  class UniformQuantiser : public Quantiser {
  public:
    UniformQuantiser(RandLMInfo* info, Stats* stats, EventType event) 
      : Quantiser(info, stats, event) {
      // only use to quantise logprobs and backoff weights
      assert(info->getEventType() & RandLMInfo::kAnyProbEvent);
      assert(~(info->getEventType() & RandLMInfo::kAnyCountEvent)); 
      assert(computeCodeBook(stats));
    }
    UniformQuantiser(RandLMInfo* info, RandLMFile* fin, EventType event) 
      : Quantiser(info, fin, event) { 
      assert(load(fin));
    }
    ~UniformQuantiser() {
    }
    bool computeCodeBook(Stats* stats);
    int getCode(float value);
    bool save(RandLMFile* out);
  private:
    bool load(RandLMFile* fin);
  };
  
  // LogQuantiser suitable for counts under relative error loss function
  class LogQuantiser : public Quantiser {
  public:
    LogQuantiser(RandLMInfo* info, Stats* stats, EventType event) 
      : Quantiser(info, stats, event), log_base_(0), code_to_log_value_(NULL) {
      // make sure only quantising counts or history counts
      assert(info->getEventType() & RandLMInfo::kAnyCountEvent);
      assert(~(info->getEventType() & RandLMInfo::kAnyProbEvent));
      assert(computeCodeBook(stats));
    }
    LogQuantiser(RandLMInfo* info, RandLMFile* fin, EventType event) 
      : Quantiser(info, fin, event), log_base_(0), code_to_log_value_(NULL) {
      assert(load(fin));
    }
    ~LogQuantiser() {
      delete[] code_to_log_value_;
    }
    bool computeCodeBook(Stats* stats);
    int getCode(float value);
    inline float getLog10Value(int code) {
      // table look up for log of values 
      return code_to_log_value_[code];
    }
    bool save(RandLMFile* out);
  private:
    bool load(RandLMFile* fin);
    float log_base_;
    float* code_to_log_value_;
  };
}

#endif // INC_RANDLM_QUANTIZER_H
