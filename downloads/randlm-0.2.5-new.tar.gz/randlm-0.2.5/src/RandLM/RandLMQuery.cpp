// Copyright 2008 David Talbot
//
// This file is part of RandLM
//
// RandLM is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// RandLM is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with RandLM.  If not, see <http://www.gnu.org/licenses/>.
#include "RandLMQuery.h"
#include <ctime>

namespace randlm {
  const std::string RandLMQuery::kQuery = "Query";

  bool RandLMQuery::query() {
    assert(test_data_ != NULL);
    WordID sentence[Corpus::kMaxSentenceWords];
    double start = clock();
    int len = 0;
    int found = 0;
    uint64_t counter = 0;
    if (corpus_data_) {// query as sentences
      while (test_data_->nextSentence(&sentence[0], &len)) {
	if (len < 3)  // <s> </s> + at least one word
	  continue;
	for (int i = 1; i < len; ++i) {
	  int start = std::max(0, i - order_ + 1);
	  if (getcounts_) // query count or prob
	    std::cout << count_randlm_->getCount(&sentence[start], i - start + 1) << std::endl; 
	  else
	    std::cout << randlm_->getProb(&sentence[start], i - start + 1, &found) << std::endl; 
	  ++counter;
	  if (counter % 1000000 == 0)
	    std::cerr << "Testing: " << counter << std::endl;
	}
      }
    } else { // query as ngrams
      while (test_data_->nextSentence(&sentence[0], &len)) {
	assert(len <= order_);
	if (getcounts_) // query count or prob
	  std::cout << count_randlm_->getCount(&sentence[0], len) << std::endl;
	else
	  std::cout << randlm_->getProb(&sentence[0], len, &found) << std::endl;
	++counter;
	if (counter % 1000000 == 0)
	  std::cerr << "Testing: " << counter << std::endl;
      }
    }
    std::cerr << "Time elapsed: " << (clock() - start)/CLOCKS_PER_SEC << std::endl;
    return true;
  }

  bool RandLMQuery::setRequirements() {
    // set up parameter requirements
    setRequire("randlm"); // path to randlm
    return true;
  }

  bool RandLMQuery::setDefaultValues() {
    // set default values to unset parameters
    setDefault("test-type", InputData::kCorpusFileType);
    setDefault("test-path", RandLMFile::kStdInDescriptor);  // stdin 
    setDefault("checks", "0"); // none
    return true;
  }

  bool RandLMQuery::load() {
    // load randlm appropriately and with or without checks
    assert(params_ != NULL && randlm_ == NULL);
    int checks = RandLMUtils::StringToInt(params_->getParamValue("checks"));      
    std::string lmpath = params_->getParamValue("randlm");
    RandLMFile fin(lmpath, std::ios::in);
    RandLMInfo* info = new RandLMInfo(&fin);
    // if specified we override the existing smoothing parameters (only affects Stupid BO).
    if (params_->checkParamIsSet("smoothing-param")) 
      info->setSmoothingParam(RandLMUtils::StringToFloat(params_->getParamValue("smoothing-param")));
    // instantiated from file based on info
    randlm_ = RandLM::initRandLM(info, &fin, checks);
    // Must init thread spcific data even though querylm is running single-threaded.
    randlm_->initThreadSpecificData();
    info = NULL;
    assert(randlm_ != NULL);
    std::cerr << "Loaded RandLM." << std::endl;
    Vocab* vocab = randlm_->getVocab();
    assert(vocab != NULL);
    order_ = randlm_->getOrder();
    // if corpus data then add <s> </s> symbols
    corpus_data_ = params_->getParamValue("test-type") == InputData::kCorpusFileType;
    test_data_ = new TestCorpus(params_->getParamValue("test-path"), 
				vocab, order_, corpus_data_);
    assert(test_data_ != NULL);
    // whether to just return ngram frequencies (only works with CountRandLM)
    // if not set we return smoothed probs
    getcounts_ = RandLMUtils::StringToBool(params_->getParamValue("get-counts"));
    if (getcounts_) {
      count_randlm_ = dynamic_cast<CountRandLM*>(randlm_);
      assert(count_randlm_ != NULL);
    }
    return true;
  }
    
}
