#include "RandLMFilter.h"
#include "RandLMFile.h"
#include "RandLMHash.h"
#include <iostream>
#include <cmath>
#include <map>
#include <iterator>
using namespace randlm;

bool setupFilter(uint64_t m, uint64_t n, UniversalHash<uint64_t>* hf, std::string path) {
  BitFilter bf(m);
  for (uint32_t i = 0; i < n; ++i)
    bf.setBit(hf->hash(&i, 1));
  RandLMFile out(path, std::ios::out);
  std::cerr << "Rho = " << bf.rho() << std::endl;
  assert(bf.save(&out));
  out.flush();
  out.close();
  return true;
}

bool testResizedFilter(uint64_t n, UniversalHash<uint64_t>* hf, std::string oldpath, std::string newpath) {
  RandLMFile oldfin(oldpath, std::ios::in);
  BitFilter bf(&oldfin);
  RandLMFile newfin(newpath, std::ios::in);
  ResizedBitFilter rbf(&newfin);
  int falseposold = 0;
  int falseposnew = 0;
  for (uint32_t i = 0; i < bf.getAddresses(); ++i) {
    if (bf.testBit(hf->hash(&i, 1))) {
      if (i > n)
	++falseposold;
      assert(rbf.testBit(hf->hash(&i, 1)));  // no 'false negs' wrt old filter allowed
    } 
    if (rbf.testBit(hf->hash(&i, 1))) 
      if (i > n)
	++falseposnew;
  } 
  std::cerr << "False pos old, new = " << falseposold << ", " << falseposnew << std::endl;
  return true;
}

int main(int argc, char** argv) {
  if (argc != 4) {
    std::cerr << "Usage ./resizetest <oldsize> <objects> <srand>" << std::endl;
    exit(1);
  }
  srand(atoi(argv[3]));
  uint64_t m = RandLMUtils::NextPrime(atoi(argv[1]));
  uint64_t n = atoi(argv[2]);
  // determine resizing 
  uint64_t newm = RandLMUtils::NextPrime(static_cast<uint64_t>(ceil(static_cast<float>(n)/log(2) + 1)))  ;
  std::cerr << "Resizing from " << m << " to " << newm << " with " << n << " insertions. " <<std::endl;
  UniversalHash<uint64_t> hf(m);
  assert(setupFilter(m, n, &hf, "oldbf"));
  RandLMFile fin("oldbf", std::ios::in);
  ResizedBitFilter rbf(&fin, newm);
  RandLMFile out("newbf", std::ios::out);
  rbf.save(&out);
  out.flush();
  out.close();
  std::cerr << "New Rho = " << rbf.rho() << std::endl;
  assert(testResizedFilter(n, &hf, "oldbf", "newbf"));
  return 0;
};
