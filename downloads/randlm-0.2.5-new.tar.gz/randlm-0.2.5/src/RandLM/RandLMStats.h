// Copyright 2008 David Talbot
//
// This file is part of RandLM
//
// RandLM is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// RandLM is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with RandLM.  If not, see <http://www.gnu.org/licenses/>.
#ifndef INC_RANDLM_STATS_H
#define INC_RANDLM_STATS_H
#include <vector>
#include "RandLMTypes.h"
#include "RandLMFile.h"
#include "RandLM.h"
#include "RandLMInfo.h"

namespace randlm {
  
  // class Stats abstract base class for statistics 
  // the 'observe' function is called to gather statistics.
  // either logprob/bo weights or count/history counts.
  // These are stored as 'main' and 'auxiliary' counts respectively
  // (as in Quantiser and RandLMStruct classes).
  class InputData;
  class NgramFile;
  class Corpus;
  class Quantiser;

  class Stats {
  public:
    // static helper methods related to estimating statistics
    static bool initStats(FileType input_type, int order, Stats*& stats);  // initialise correct subclass
    static bool getStats(Stats* stats, InputData* data);  // estimate stats from data (if required)
    static bool getTokenStats(Stats* stats, Corpus* corpus);
    static bool getNgramStats(Stats* stats, NgramFile* ngrams);
    Stats(int max_order) : order_specific_(max_order > 1), estimated_(false), 
      max_order_(max_order), require_sorted_(false), total_main_(0), total_aux_(0),
      main_event_(RandLMInfo::kNullEvent), aux_event_(RandLMInfo::kNullEvent),
      tokens_(0), estimated_tokens_(false), zipf_(0){}
    virtual ~Stats() {}
    // retrieve statistics for this order / event type
    bool getCounts(FloatCounts & counts, EventType event, int order = 0);
    // retrieve quantised counts using this quantiser
    bool getQuantisedCounts(Quantiser* quantiser, CodeCounts & quant_counts, 
			    EventType event, int order = 0);
    // calls to start and end estimation (all intervening calls to 'observe' are logged)
    virtual bool start() {
      // don't overwrite
      if (estimated_)
	return false;
      return init();
    }
    virtual bool finish() { 
      if (estimated_)
	return false;
      estimated_ = true; 
      return true;
    }
    // 'observe' is called for each statistics
    // (implementations may require ngrams to be sorted).
    virtual bool observe(const WordID* ngram, Value value, int len) = 0;       
    virtual bool observe(const Word* ngram, Value value, int len) = 0; 
    virtual bool requireSortedByNgram() { return require_sorted_; }
    bool isOrderSpecific() { return order_specific_; }
    bool hasNgramStats() { return estimated_; }
    bool hasTokenStats() { return estimated_tokens_; }
    bool setTokenStats(uint64_t tokens) { 
      tokens_ = tokens; 
      estimated_tokens_ = true;
      return tokens_ > 0;
    }
    uint64_t getTokenCount() {
      return estimated_tokens_ ? tokens_ : 0;
    }
    bool setSkew(float zipf) {
      zipf_ = zipf;
      return zipf_ > 1.0;
    }
    float getSkew() {
      return zipf_;
    }
    bool saveTokenStats(const std::string &wcpath) {
      assert(estimated_tokens_);
      RandLMFile wcout(wcpath,  std::ios::out);
      wcout << tokens_ << "\n";
      wcout.close();
      return true;
    }
    int getMaxOrder() { return max_order_; }
    // i/o functions
    bool save(const std::string & stats_path) {
      assert(estimated_);
      RandLMFile statsout(stats_path, std::ios::out);
      assert(save(&statsout));
      statsout.close();
      return true;
    }
    bool load(const std::string & stats_path) {
      RandLMFile statsin(stats_path, std::ios::in);
      assert(load(&statsin));
      return true;
    }
    bool save(RandLMFile* fout);
    bool load(RandLMFile* fin);
    bool hasStatsFor(EventType event) {
      return (event == (main_event_ | aux_event_)) ||
	(event == main_event_) || (event == aux_event_);
    }
    uint64_t total_main() const { return total_main_; }
    uint64_t total_aux() const { return total_aux_; }
  protected:
    bool init();
    bool order_specific_;
    bool estimated_; 
    int max_order_;
    bool require_sorted_; 
    uint64_t total_main_;  // count or logprob
    uint64_t total_aux_;  // history or backoff weight
    std::vector<FloatCounts> main_counts_;
    std::vector<FloatCounts> aux_counts_; 
    EventType main_event_;  // types of events for which stats are stored
    EventType aux_event_;
    uint64_t tokens_;
    bool estimated_tokens_;
    float zipf_;
  };
  
  // BackoffStats stores statistics for logprobs and backoff weights separately
  class BackoffStats : public Stats {
  public:
    BackoffStats(int max_order) : Stats(max_order) {
      main_event_ = RandLMInfo::kLogProbEvent;
      aux_event_ = RandLMInfo::kBackoffWeightEvent;
    }
    bool observe(const WordID* ngram, Value value, int len);
    bool observe(const Word* ngram, Value value, int len);
  private:
    bool observe(Value value, int order = 0);
  };

  // CountStats stores statistics for ngram and history counts separately
  class CountStats : public Stats {
  public:
    CountStats(int max_order) : Stats(max_order) {
      require_sorted_ = true; 
      main_event_ = RandLMInfo::kCountEvent;
      aux_event_ = RandLMInfo::kHistoryEvent;
    }
    bool observe(const WordID* ngram, Value value, int len);
    bool observe(const Word* ngram, Value value, int len);
    bool start();
    bool finish();
  private:
    // structures to track history counts for different orders
    uint64_t this_history_count_[RandLM::kMaxNgramOrder]; 
    bool first_entry_[RandLM::kMaxNgramOrder];
    Word this_history_[RandLM::kMaxNgramOrder][RandLM::kMaxNgramOrder];
  };

}
#endif // INC_RANDLM_STATS_H
