// Copyright 2008 David Talbot
//
// This file is part of RandLM
//
// RandLM is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// RandLM is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with RandLM.  If not, see <http://www.gnu.org/licenses/>.
#include "RandLMPreproc.h"
#include "RandLMStruct.h"
#include "LogFreqBloomFilter.h"
#include "LogFreqSketch.h"
#include "BloomMap.h"
#include "CountMinSketch.h"
#include "BloomierFilter.h"
#include "LossyDict.h"

namespace randlm {

  const std::string RandLMStruct::kNullStruct = "NullStruct";
  const std::string RandLMStruct::kLogFreqBloomFilter = "LogFreqBloomFilter";
  const std::string RandLMStruct::kLogFreqSketch = "LogFreqSketch";
  const std::string RandLMStruct::kLossyDict = "LossyDict";
  const std::string RandLMStruct::kBloomierFilter = "BloomierFilter";
  const std::string RandLMStruct::kBloomMap = "BloomMap";
  const std::string RandLMStruct::kCountMinSketch = "CountMinSketch";

  const int RandLMStruct::kNullStructCode;
  const int RandLMStruct::kLogFreqBloomFilterCode;
  const int RandLMStruct::kLogFreqSketchCode;
  const int RandLMStruct::kLossyDictCode;
  const int RandLMStruct::kBloomMapCode;
  const int RandLMStruct::kCountMinSketchCode;

  const std::string RandLMStruct::kNullEstimation = "__NULL__";
  const std::string RandLMStruct::kBatchEstimation = "batch";
  const std::string RandLMStruct::kOnlineEstimation = "online";
  const std::string RandLMStruct::kCoinTossingEstimation = "coins";
  
  const int RandLMStruct::kNullEstimationCode;
  const int RandLMStruct::kBatchEstimationCode;
  const int RandLMStruct::kOnlineEstimationCode;
  const int RandLMStruct::kCoinTossingEstimationCode;

  const int RandLMStruct::kNullCode;
  const int RandLMStruct::kUnknownCode;
  const int RandLMStruct::kMaxCode;

  bool RandLMStruct::getStructCode(const std::string & struct_name, StructCode* struct_code) {
    // convert strings used on cmd line to integer codes
    *struct_code = kNullStructCode;
    if (struct_name == RandLMStruct::kLogFreqBloomFilter)
      *struct_code = kLogFreqBloomFilterCode;
    else if (struct_name == RandLMStruct::kLogFreqSketch)
      *struct_code = kLogFreqSketchCode;
    else if (struct_name == RandLMStruct::kBloomMap)
      *struct_code = kBloomMapCode;
    else if (struct_name == RandLMStruct::kBloomierFilter)
      *struct_code = kBloomierFilterCode;
    else if (struct_name == RandLMStruct::kCountMinSketch)
      *struct_code = kCountMinSketchCode;
    else if (struct_name == RandLMStruct::kLossyDict)
      *struct_code = kLossyDictCode;
    return *struct_code != kNullStructCode;
  }
  bool RandLMStruct::getEstimatorCode(const std::string & scheme, int* code) {
    *code = kNullEstimationCode;
    if (scheme == kBatchEstimation)
      *code = kBatchEstimationCode;
    else if (scheme == kOnlineEstimation)
      *code = kOnlineEstimationCode;
    else if (scheme == kCoinTossingEstimation)
    *code = kCoinTossingEstimationCode;
    return *code != kNullEstimationCode;
  }
  std::string RandLMStruct::getEstimatorName(int code) {
    std::string scheme = kNullEstimation;
    switch (code) {
    case kBatchEstimationCode:
      scheme = kBatchEstimation;
      break;
    case kOnlineEstimationCode:
      scheme = kOnlineEstimation;
      break;
    case kCoinTossingEstimationCode:
      scheme = kCoinTossingEstimation;
      break;
    }
    return scheme;
  }
  RandLMStruct* RandLMStruct::initStruct(RandLMInfo* info) {
    // instantiate correct randomised data structure
    assert(info != NULL);
    switch (info->getStructType()) {
    case RandLMStruct::kLogFreqBloomFilterCode:
      return new LogFreqBloomFilter(info);
    case RandLMStruct::kLogFreqSketchCode: 
      return new LogFreqSketch(info);
    case RandLMStruct::kBloomMapCode:
      return new BloomMap(info);
    case  RandLMStruct::kBloomierFilterCode:
      return new BloomierFilter(info);
    case  RandLMStruct::kCountMinSketchCode:
      return new CountMinSketch(info);
    case  RandLMStruct::kLossyDictCode:
      return new LossyDict(info);
    }
    return NULL;
  }
  RandLMStruct* RandLMStruct::initStructFromFile(RandLMInfo* info, RandLMFile* fin) {
    // instantiate correct randomised data structure
    assert(info != NULL && fin != NULL);
    switch (info->getStructType()) {
    case RandLMStruct::kLogFreqBloomFilterCode:
      return new LogFreqBloomFilter(info, fin);
    case RandLMStruct::kLogFreqSketchCode: 
      return new LogFreqSketch(info, fin);
    case RandLMStruct::kBloomMapCode:
      return new BloomMap(info, fin);
    case  RandLMStruct::kBloomierFilterCode:
      return new BloomierFilter(info, fin);
    case  RandLMStruct::kCountMinSketchCode:
      return new CountMinSketch(info, fin);
    case  RandLMStruct::kLossyDictCode:
      return new LossyDict(info, fin);
    }
    return NULL;
  }
  bool RandLMStruct::supportsOnlineUpdates(StructCode code) {
    return code == kLogFreqSketchCode || code == kCountMinSketchCode;
  }
  bool RandLMStruct::requiresCoinTossingUpdates(StructCode code) {
    return code == kLogFreqSketchCode;
  }
  bool RandLMStruct::canStoreAnyEventType(StructCode code) {
    // can store any types of value (i.e. not restricted to counts)
    return code == kBloomMapCode || code == kBloomierFilterCode ||
      code == kLossyDictCode;
  }
  bool RandLMStruct::canStore(StructCode code, EventType events) {
    // can't store 'null' events
    assert(events != RandLMInfo::kNullEvent);
    // any structure can store counts directly (including counts of histories)
    events &= ~(RandLMInfo::kCountEvent | RandLMInfo::kHistoryEvent);
    // if other events specified then check compatibility
    return events == RandLMInfo::kNullEvent ? true : canStoreAnyEventType(code); 
  }
  bool RandLMStruct::getDefaultEstimator(StructCode code, FileType input_type, Estimator* estimator) {
    // If input data is precomputed or struct is static then require batch estimation
    *estimator = kNullEstimationCode;
    if (input_type != InputData::kCorpusFileType || !supportsOnlineUpdates(code))
      *estimator = kBatchEstimationCode;
    else  // default to online estimation if passed a corpus (using prob counting only if necessary)
      *estimator = requiresCoinTossingUpdates(code) ? kCoinTossingEstimationCode :  kOnlineEstimationCode;      
    return *estimator != kNullEstimationCode;
  }
  // instantiate base member data
  bool RandLMStruct::initMembers(RandLMInfo* info) {
    assert(info != NULL && info_ == NULL);
    // get distinct local copy of info
    info_ = new RandLMInfo(*info);
    num_events_ = RandLMInfo::getNumEvents(info_->getEventType());
    order_ = info_->getMaxOrder();
    order_specific_ = info_->isOrderSpecific();
    max_code_ = new int[num_events_];
    min_code_ = new int[num_events_];
    for (int i = 0; i < num_events_; ++i) {
      max_code_[i] = 0; 
      min_code_[i] = RandLMStruct::kMaxCode;
    }
    return true;    
  }
  // i/o functionality
  bool RandLMStruct::load(RandLMFile* fin) {
    // read randlm_info from head of file
    assert(info_ != NULL);  // set in initMembers
    // load info from file
    RandLMInfo info(fin);
    // check compatible with this structure
    assert(info_->equals(&info));
    // load member data
    for (int i = 0; i < num_events_; ++i) {
      assert(fin->read((char*)&max_code_[i], sizeof(max_code_[i])));
      assert(fin->read((char*)&min_code_[i], sizeof(min_code_[i])));
    }
    assert(fin->read((char*)&working_mem_, sizeof(working_mem_)));
    assert(fin->read((char*)&full_, sizeof(full_)));
    assert(fin->read((char*)&optimised_, sizeof(optimised_)));
    return true;
  }
  bool RandLMStruct::save(RandLMFile* fout) {
    assert(info_ != NULL);
    // save info first
    assert(info_->save(fout));
    // save member data
    for (int i = 0; i < num_events_; ++i) {
      assert(fout->write((char*)&max_code_[i], sizeof(max_code_[i])));
      assert(fout->write((char*)&min_code_[i], sizeof(min_code_[i])));
    }
    assert(fout->write((char*)&working_mem_, sizeof(working_mem_)));
    assert(fout->write((char*)&full_, sizeof(full_)));
    assert(fout->write((char*)&optimised_, sizeof(optimised_)));
    return true;
  }
  // additional i/o for OnlineRandLM
  bool OnlineRandLMStruct::save(RandLMFile* fout) {
    // doesn't call parent since not on main hierarchy
    assert(fout->write((char*)&expected_tokens_, sizeof(expected_tokens_)));
    assert(fout->write((char*)&observed_tokens_, sizeof(observed_tokens_)));
    return true;
  }
  bool OnlineRandLMStruct::load(RandLMFile* fin) {
    // load additiona member data
    assert(fin->read((char*)&expected_tokens_, sizeof(expected_tokens_)));
    assert(fin->read((char*)&observed_tokens_, sizeof(observed_tokens_)));
    return true;
  }

} // ends namespace
