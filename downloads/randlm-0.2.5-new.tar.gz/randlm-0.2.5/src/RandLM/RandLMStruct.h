// Copyright 2008 David Talbot
//
// This file is part of RandLM
//
// RandLM is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// RandLM is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with RandLM.  If not, see <http://www.gnu.org/licenses/>.
#ifndef INC_RANDLM_STRUCT_H
#define INC_RANDLM_STRUCT_H

#include <map>
#include <vector>
#include "RandLMTypes.h"
#include "RandLMUtils.h"
#include "RandLMInfo.h"

namespace randlm {

  // class RandStruct: abstract base class defining an interface 
  // for constructing and querying randomised data structures .
  
  // Abstract subclasses are in this file.
  // Implementations are in separate files.
  
  // Constructors in these abstract classes implement constraints on types
  // of value that can be stored and how they can be updated.
  
  // Methods that are involved in inserting data (e.g insert/observe/add)
  // may also impose constraints on order in which data should be inserted.
  
  // Some methods have an 'ngram' (i.e. sequence) version and a 'word' version.
  // The latter are for repeated operations on sequences that differ only by one item
  // added to left on each call. e.g. they can be called as f(B), f(A) to get f(AB). 
  // They are used by RandLM for efficient lookup of ngrams when checking for subngrams first.
  
  // Value stored in these data structures are all quantised codes.
  // Quantisation is handled by the RandLM that owns the RandLMStruct.

  // forward declarations
  class InputData; 
  class Vocab;
  class Stats;
  class RandLM;
  class Quantiser;

  class RandLMStruct {
  public:
    // descriptors for different structs
    static const std::string kNullStruct;
    static const std::string kLogFreqBloomFilter;
    static const std::string kLogFreqSketch;
    static const std::string kLossyDict;
    static const std::string kBloomierFilter;
    static const std::string kBloomMap;
    static const std::string kCountMinSketch;

    static const StructCode kNullStructCode = 0;
    static const StructCode kLogFreqBloomFilterCode = 1;
    static const StructCode kLogFreqSketchCode = 2;
    static const StructCode kLossyDictCode = 3;
    static const StructCode kBloomierFilterCode = 4;
    static const StructCode kBloomMapCode = 5;
    static const StructCode kCountMinSketchCode = 6;

    static const std::string kNullEstimation;
    static const std::string kBatchEstimation;
    static const std::string kOnlineEstimation;
    static const std::string kCoinTossingEstimation;

    static const int kNullEstimationCode = 0;
    static const int kBatchEstimationCode = 1;
    static const int kOnlineEstimationCode = 2;
    static const int kCoinTossingEstimationCode = 3;

    static const int kNullCode = -1;  // queried but not found
    static const int kUnknownCode = 1 << 17; // not queried (must be larger than maximum code)
    static const int kMaxCode = 1 << 16; 

    // helper method for preprocessing
    static bool getStructCode(const std::string & struct_name, StructCode* code);
    static bool getEstimatorCode(const std::string & estimation_scheme, int* estimator);
    static std::string getEstimatorName(int estimator);
    static bool supportsOnlineUpdates(StructCode code);
    static bool requiresCoinTossingUpdates(StructCode code);
    static bool canStoreAnyEventType(StructCode code);
    static bool canStore(StructCode code, EventType events);
    static bool getDefaultEstimator(StructCode code, FileType input_type, Estimator* estimator);
    static RandLMStruct* initStruct(RandLMInfo* info);
    static RandLMStruct* initStructFromFile(RandLMInfo* info, RandLMFile* fin);

    // initialise from RandInfo and statistics
    RandLMStruct(RandLMInfo* info) 
      : info_(NULL), num_events_(0), order_(0), order_specific_(false),
      max_code_(NULL), min_code_(NULL), working_mem_(0), full_(false),
      optimised_(false) {
      assert(info != NULL);
      assert(canStore(info->getStructType(), info->getEventType()));
      assert(initMembers(info)); 
    }
    // load from file
    RandLMStruct(RandLMInfo* info, RandLMFile* fin)
      : info_(NULL), num_events_(0), order_(0), order_specific_(false),
      max_code_(NULL), min_code_(NULL), working_mem_(0), full_(false),
      optimised_(false) {
      assert(info != NULL && fin != NULL);
      assert(canStore(info->getStructType(), info->getEventType()));
      assert(initMembers(info));
      assert(load(fin));
    }
    virtual ~RandLMStruct() {
      delete info_;  // this is a distinct copy
      delete[] max_code_;
      delete[] min_code_;
    }
    // insert/query functions for sequences: associates 'code' with 'ngram'.
    // 'aux' specifies whether we're querying the 'main' or 'auxiliary'
    virtual bool insert(const WordID* ngram, int len, int event_idx, int code) = 0;
    // optional parameter 'max' allows for an upperbound on 'code' to be specified
    virtual bool query(const WordID* ngram, int len, int event_idx, int* code, int max = kMaxCode) = 0;
    // incremental version of query (see example use above)
    virtual bool query(const WordID word, int start, int end, int event_idx, int* code, 
		       int max = kMaxCode) = 0;
    // pass information regarding expected number of codes of this event type and order
    virtual bool setCodeCounts(CodeCounts counts, uint64_t total, int event_idx, 
			       int order = kMaxCode) { return false; }
    // optimise the structure
    virtual bool optimise(float working_mem) = 0;
    // generic i/o
    virtual bool save(RandLMFile* fout); 
    virtual uint64_t getSize() = 0;
  protected:
    bool load(RandLMFile* fin);  // called in constructor so not type specific
    bool initMembers(RandLMInfo* info);
    // member data
    RandLMInfo* info_;  // meta data (owned)
    int num_events_;  // number of distinct event types stored
    int order_;  // max ngram order
    bool order_specific_;  // whether errors are specified per ngram order
    int* max_code_;  // max code per event idx
    int* min_code_;  // min code
    float working_mem_;  // amount of memory available during creation
    bool full_; // whether calls to insert/count will fail
    bool optimised_;  // whether we've optimised it's space given statistics
  };
  
  // StaticRandLMStruct can only be constructed in batch mode.
  class StaticRandLMStruct : public RandLMStruct {
  public:
    StaticRandLMStruct(RandLMInfo* info) : RandLMStruct(info) {
      // check that estimator is batch
      assert(info->getEstimator() == RandLMStruct::kBatchEstimationCode);
    }
    StaticRandLMStruct(RandLMInfo* info, RandLMFile* fin) 
      : RandLMStruct(info, fin) {
      // check that estimator is batch
      assert(info->getEstimator() == RandLMStruct::kBatchEstimationCode);
    }
  };

  // OnlineRandStruct also allows counts to be updated online.  
  class LogQuantiser;

  class OnlineRandLMStruct : public virtual RandLMStruct {
  public:
    OnlineRandLMStruct(RandLMInfo* info) 
      : RandLMStruct(info), expected_tokens_(0), observed_tokens_(0) {
      // currently can't store anything else online
      assert(info->getEventType() == RandLMInfo::kCountEvent);
    }
    OnlineRandLMStruct(RandLMInfo* info, RandLMFile* fin) 
      : RandLMStruct(info, fin), expected_tokens_(0), observed_tokens_(0) {
      // currently can't store anything else online
      assert(info->getEventType() == RandLMInfo::kCountEvent);
      assert(load(fin));
    }
    // updates counts to reflect single observation of 'ngram' 
    virtual bool count(const WordID* ngram, int len) = 0;
    // incremental version see query example above
    virtual bool count(const WordID word, int start, int end) = 0;
    // set statistics for data stream
    virtual bool setExpectedTokens(uint64_t tokens) {
      expected_tokens_ = tokens; 
      return expected_tokens_ > 0;
    }
    // online estimation requires quantiser to interpret codes as counts 
    virtual bool assignCountMapping(LogQuantiser* log_quantiser) = 0;
    virtual bool save(RandLMFile* fout);
    virtual void printOnlineStats() {};  // no-op base
  protected:
    bool load(RandLMFile* fin); 
    uint64_t expected_tokens_;  // number of tokens to expect (may not be set i.e. 0)
    uint64_t observed_tokens_;  // number of tokens observed  
  };
  
} // ends namespace

#endif //INC_RANDLM_STRUCT_H
