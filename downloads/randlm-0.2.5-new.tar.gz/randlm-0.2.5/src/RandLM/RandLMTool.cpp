// Copyright 2008 David Talbot
//
// This file is part of RandLM
//
// RandLM is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// RandLM is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with RandLM.  If not, see <http://www.gnu.org/licenses/>.
#include "RandLMTool.h"
#include <iterator>

namespace randlm {
  
  bool RandLMTool::checkParams(const std::string & caller) {
    std::string err = "**ERROR ";
    // first set up requirements
    assert(setRequirements());  // get subclass requirements
    std::cerr << "Default values set in " << caller << ":" << std::endl;
    assert(setDefaultValues()); // set defaults if no user specified values
    // check parameter requirements and print out some information
    // if things don't look good.
    // check required parameters
    if (!params_->checkAllSet(required_)) {
      std::cerr << err << "ALL of the following parameters must be set:" <<std::endl;
      printParamSet(required_);
      assert(false);
    }
    // check disallowed parameters
    if (!params_->checkNoneSet(disallowed_)) {
      std::cerr << err << "NONE of the following parameters should be set:" <<std::endl;
      printParamSet(disallowed_);
      assert(false);
    }
    // iterators used for conditioned and unconditioned parameters
    std::map<std::string, ParamSet>::const_iterator cit;
    std::set<ParamSet>::const_iterator it;
    // check conditionally required params
    for (cit = cond_required_.begin(); cit != cond_required_.end(); ++cit)
      if (params_->checkParamIsSet(cit->first))
	if (!params_->checkAllSet(cit->second)) {
	  std::cerr << err << "When \'" << cit->first 
		    << "\' is set ALL the following parameters must be set:" <<std::endl;
	  printParamSet(cit->second);
	  assert(false);
	}
    // check for parameters of which at least one should be set
    for (it = one_required_.begin(); it != one_required_.end(); ++it)
      if(params_->checkNoneSet(*it)) { // can't have none set
	std::cerr << err << "At least ONE of the following parameters must be set:" <<std::endl;
	printParamSet(*it);
	assert(false);
      }
    // check for parameters of which at least one should be set conditionall
    for (cit = cond_one_required_.begin(); cit != cond_one_required_.end(); ++cit)
      if (params_->checkParamIsSet(cit->first))
	if (params_->checkNoneSet(cit->second)) {
	  std::cerr << err << "When \'" << cit->first 
		    << "\' is set at least ONE of the following parameters must be set:" <<std::endl;
	  printParamSet(cit->second);
	  assert(false);
	}
    // check for disallowed combinations of parameters
    for (cit = cond_disallowed_.begin(); cit != cond_disallowed_.end(); ++cit)
      if (params_->checkParamIsSet(cit->first)) {
	if(!params_->checkNoneSet(cit->second)) {
	  std::cerr << err << "When \'" << cit->first 
		    << "\' is set NONE of the following parameters can be set:" <<std::endl;
	  printParamSet(cit->second);
	  assert(false);
	}
      }
    // check for disallowed name->value pairs
    std::map<std::string, ValueSet>::const_iterator vit;
    for (vit = disallowed_values_.begin(); vit != disallowed_values_.end(); ++vit)
      if (params_->checkParamIsSet(vit->first)) {
        std::string val = params_->getParamValue(vit->first);
        ValueSet::const_iterator sit = vit->second.begin();
        for(; sit != vit->second.end(); sit++ ) {
          if( *sit == val ) {
            std::cerr << err << "Parameter \'" << vit->first 
                      << "\' can not take any of the following values with this tool:" << std::endl;
            printParamSet(vit->second);
            assert(false);
          }
        }
      }
    // check for required name->value pairs
    std::map<std::string, std::string>::const_iterator rit;
    for (rit = required_values_.begin(); rit != required_values_.end(); ++rit)
      if (params_->checkParamIsSet(rit->first)) {
	if(params_->getParamValue(rit->first) != rit->second) {
	  std::cerr << err << "If parameter \'" << rit->first 
		    << "\' is set, it must have value \'" << rit->second 
		    << "\' with this tool." << std::endl;
	  assert(false);
	}
      }
    return true;
  }
  
  bool RandLMTool::setRequire(const std::string & name, const std::string & cond_name) {
    // determine whether conditional requirements
    assert(RandLMParams::isValidParamName(name));
    if (cond_name.size() == 0) {
      required_.insert(name);
    } else {
      assert(RandLMParams::isValidParamName(cond_name));
      if (cond_required_.find(cond_name) == cond_required_.end())
	cond_required_[cond_name] = ParamSet();
      cond_required_[cond_name].insert(name);
    }
    return true;
  }

  bool RandLMTool::setRequireOne(const ParamSet & paramSet, const std::string & cond_name) {
    // determine whether conditional requirements
    for (ParamSet::const_iterator it = paramSet.begin(); it != paramSet.end(); ++it)
      assert(RandLMParams::isValidParamName(*it));
    if (cond_name.size() == 0) {
      one_required_.insert(paramSet);
    } else {
      assert(RandLMParams::isValidParamName(cond_name));
      if (cond_one_required_.find(cond_name) == cond_one_required_.end())
	cond_one_required_[cond_name] = paramSet;
      return false; // since may be conflict
    }
    return true;
  }

  bool RandLMTool::setDisallow(const std::string & name, const std::string & cond_name) {
    // determine whether conditional requirements
    assert(RandLMParams::isValidParamName(name));
    if (cond_name.size() == 0) {
      disallowed_.insert(name);
    } else {
      assert(RandLMParams::isValidParamName(cond_name));
      if (cond_disallowed_.find(cond_name) == cond_disallowed_.end())
	cond_disallowed_[cond_name] = ParamSet();
      cond_disallowed_[cond_name].insert(name);
    }
    return true;
  }
  
  bool RandLMTool::setDisallowValue(const std::string & name, const std::string & value) {
    // set value that is not allowed for this tool
    assert(RandLMParams::isValidParamSetting(name, value)); 
    if (disallowed_values_.find(name) == disallowed_values_.end()) 
      disallowed_values_[name] = ValueSet();
    disallowed_values_[name].insert(value);
    return true;
  }
  
  bool RandLMTool::setRequireValue(const std::string & name, const std::string & value) {
    // set value that is not allowed for this tool
    assert(RandLMParams::isValidParamSetting(name, value)); 
    // can't be required to be set to more than one value
    assert(required_values_.find(name) == required_values_.end());
    required_values_[name] = value;
    return true;
  }

  bool RandLMTool::setDefault(const std::string & name, const std::string & value) {
    // set parameter 'name' = 'value' unless already set by user or 
    if (!params_->checkParamIsSet(name)) {
      std::cerr << "\t"<< name << "\t" << value << std::endl;
      params_->setParamValue(name, value);
    }
    return true;
  }

  bool RandLMTool::setDefault(const std::string & name, const std::string & value, 
			      const std::string & cond_name) {
    // set parameter 'name' = 'value' unless already set by user
    // iff parameter 'cond_name' is set
    if (!params_->checkParamIsSet(name) && params_->checkParamIsSet(cond_name)) {
      std::cerr << "\t"<< name << "\t" << value << std::endl;
      params_->setParamValue(name, value);
    }
    return true;
  }


  bool RandLMTool::setDefault(const std::string & name, const std::string & value, 
			      const std::string & cond_name, const std::string & cond_value) {
    // set parameter 'name' = 'value' unless already set by user
    // iff parameter 'cond_name' = 'cond_value'
    if (!params_->checkParamIsSet(name) && params_->getParamValue(cond_name) == cond_value) {
      std::cerr << "\t"<< name << "\t" << value << std::endl;
      params_->setParamValue(name, value);
    }
    return true;
  }

  bool RandLMTool::printParamSet(const ParamSet & paramSet) const {
    // print out param set to cerr
    for (ParamSet::const_iterator it = paramSet.begin(); 
	 it != paramSet.end(); ++it)
      std::cerr << "\t" << *it << std::endl;
    return true;
  }
}
