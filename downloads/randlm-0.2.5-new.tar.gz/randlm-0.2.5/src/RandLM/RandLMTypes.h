// Copyright 2008 David Talbot
//
// This file is part of RandLM
//
// RandLM is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// RandLM is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with RandLM.  If not, see <http://www.gnu.org/licenses/>.
#ifndef RANDLM_TYPES_H
#define RANDLM_TYPES_H

#include <map>
#include <string>
#include <stdint.h>

#define iterate(c,i) for(typeof(c.begin()) i = c.begin(); i != c.end(); i++)

namespace randlm {

  // Contains typedefs used across multiple files in RandLM

  typedef std::string Word; // word as string 
  typedef uint32_t WordID;  // word mapped to integer
  typedef std::string FileType; // one of list of standard file formats
  typedef uint8_t Format;   // use each bit represents a boolean formatting attribute

  typedef uint8_t EventType;  // different types that can be associated with ngrams
  typedef int StructCode;  // codes for different randomised data strucures
  typedef int Smoothing;
  typedef int Estimator;

  //typedef uint64_t Value;  // value associated with an ngram
  union Value{
    uint64_t uint;
    float floats[2];
  };

  typedef std::map<Value, uint64_t> ValueCounts; // used by Stats
  typedef std::map<int, uint64_t> CodeCounts; // used for quantised stats
  typedef std::map<float, uint64_t> FloatCounts; // used by Stats
  
};

#endif // RANDLM_TYPES_H 
