#include <cstdlib>
#include <cmath>
#include <fstream>
#include <iostream>
#include <sstream>
#include <map>
#include <set>
#include <vector>
#include <string>
#include <stdint.h>
#include <cassert>
#define BOS "<s>"
#define EOS "</s>"
using namespace std;

// Count occurences in <stdin> of all ngrams observed in <test> up to order <order>

// On first call get test ngrams from <test>
// On second call count their frequency in stdin
// then output various stats as requested

bool nextSentence(istream* input, vector<string> &sentence) {
  string line; 
  while (getline(*input, line)) {
    istringstream buffer(line.c_str());
    string word;
    // get words
    sentence.clear();
    sentence.push_back(BOS);
    while (buffer >> word)
      sentence.push_back(word);
    sentence.push_back(EOS);
    if (sentence.size() < 3) {
      cerr << "Warning: empty line in corpus" << endl; 
      continue;
    }
    return true;
  }
  return false;
}

float sbo(vector<string>& ngram, map<vector<string>, uint64_t> & testngrams, float alpha,
	  uint64_t distinct_types, uint64_t corpus_size) {
  // provide sbo estimate for relative frequency of ngram
  vector<string> num;
  vector<string> denom;
  uint64_t denomcount  = 0;
  uint64_t numcount = 0;
  int len = ngram.size();
  int found = len;
  while (found > 0) {
    num.clear();
    for (int i = len - found; i < len; ++i)
      num.push_back(ngram[i]);
    if (testngrams.count(num) == 0 || testngrams[num] == 0) {
      --found;
      continue;
    }
    // found num
    numcount = testngrams[num];
    if (found > 1) {
      denom.clear();
      for (int i = len - found; i < len - 1; ++i)
	denom.push_back(ngram[i]);
      assert(testngrams.count(denom) > 0);
    }
    break;
  }
  denomcount = found > 1 ? testngrams[denom] : corpus_size;
  // get appropriate counts
  if (found == 0)
    return len * log10(alpha) - log10(distinct_types);
  assert(denomcount >= numcount);
  assert(numcount > 0);
  return (len - found) * log10(alpha) + log10(numcount) - log10(denomcount);
}

uint64_t freq(vector<string>& ngram, map<vector<string>, uint64_t> & testngrams) {
  // just get frequency
  if (testngrams.count(ngram) > 0)
    return testngrams[ngram];
  cerr << "not found" << endl;
  return 0;
}

bool countngrams(string testpath, int order, map<vector<string>, uint64_t> & testngrams, 
		 bool count, bool tokendist, float alpha) {
  // if "count" then count ngrams in testngrams as observed on stdin
  // if not "count" get testngrams from test
  string line;
  ifstream test(testpath.c_str());
  uint64_t counter = 0;
  uint64_t tokens = 0;
  vector<string> sentence;
  set<string> types;
  while (nextSentence(count ? &cin : &test, sentence)) {
    ++counter;
    tokens += (sentence.size() - 1); // don't count <s> as a token
    // get all ngrams
    int sentlen = sentence.size();
    for (int i = 1; i <= order; ++i) 
      for (int j = 0; j + i - 1 < sentlen; ++j) {
	// count types in corpus on second pass
	if (i == 1 && count)
	  types.insert(sentence[j]);
	vector<string> ngram;
	for (int k = 0; k < i; ++k)
	  ngram.push_back(sentence[j+k]);
	// count testngrams on second pass
	if (count) {
	  if (testngrams.count(ngram))
	    ++testngrams[ngram];
	} else {
	  // just collect distinct types from testset on first pass
	  testngrams[ngram] = 0;
	}
      }
  }
  test.close();
  cerr << (count ? "training corpus" : "test corpus" ) << " has " << counter << " lines "
       << " and " << tokens << " tokens" << std::endl;
  uint64_t distinct_types = types.size();
  // output counts
  if (count) {
    if (!tokendist) {
      // output count once for each 'type'
      for (map<vector<string>, uint64_t>::const_iterator iter = testngrams.begin();
	   iter != testngrams.end(); ++iter) {
	cout << iter->second << "\t";
	for (uint32_t i = 0; i < iter->first.size(); ++i)
	  cout << iter->first[i] << ( i == iter->first.size() - 1 ? "\n" : "\t");
      }
    } else {
      // read in test set again and score each ngram 'token'
      ifstream testfile(testpath.c_str());
      int testcounter = 0;
      while (nextSentence(&testfile, sentence)) {
	// iterate over ngrams scores starting with first bigram (don't predict <s>)
	int sentlen = sentence.size();
	for (int i = 1; i < sentlen; ++i) {
	  vector<string> ngram;
	  for (int j = max(0, i - order + 1); j <= i; ++j)
	    ngram.push_back(sentence[j]);
	  ++testcounter;
	  if (alpha > 0)
	    cout << sbo(ngram, testngrams, alpha, distinct_types, tokens);
	  else
	    cout << freq(ngram, testngrams);
	  for (uint32_t k = 0; k < ngram.size(); ++k)
	    cout << "\t" << ngram[k];
	  cout << endl;
	}
      }
      cerr << "scored " << testcounter << " ngrams" << endl;
    }
  }
  return true;
}

int main(int argc, char** argv) {
  if (argc != 5) {
    // <token-dist> results in 'corpus' distribution being written
    // otherwise each type in <test> is scored once only.
    // if alpha is > 0 then stupid backoff probs will be written
    cerr << "usage ./countngrams <test> <order> <token-dist> <alpha> < training" <<endl;
    exit(1);
  }
  string testpath = argv[1];
  int order = atoi(argv[2]);
  bool tokendist = atoi(argv[3]);
  float alpha = atof(argv[4]);
  map<vector<string>, uint64_t> testngrams;
  // get testngrams from <test>
  assert(countngrams(testpath, order, testngrams, false, tokendist, alpha));
  // count their frequency in stdin data and write scores to stdout
  assert(countngrams(testpath, order, testngrams, true, tokendist, alpha));
  return 0;
}
