#include <cstdlib>
#include <fstream>
#include <sstream>
#include <iostream>
#include <stdint.h>
#include <cassert>
#include <string>
#include <map>
#include <cmath>
#define FLOATERR 0.0001  // ignore differences of less than this size 

#define FALSEPOS 0
#define FALSENEG 1

#define ADDERROR 2
#define RELERROR 3

#define ABSMSE 4
#define RELMSE 5

#define ABSTHRESHOLD 6
#define RELTHRESHOLD 7
using namespace std;

// Compute various error rates 

// Assumes two files <cand> <ref> with same number of lines and
// one score as first entry per line in each file.

// Error rates are compute on an order specific basis.

bool errorrate(string refpath, string candpath, int order, int error_code, float eps) {
  map<float, float> poserrs;
  map<float, float> negerrs;
  map<float, float> counterrs;
  map<float, int> counterrstotals;
  map<int, float> errors; 
  map<int, int> totals;
  for (int i = 0; i < order; ++i) {
    errors[i] = 0;
    totals[i] = 0;
  }
  ifstream ref(refpath.c_str());
  ifstream cand(candpath.c_str());
  string refline, candline;
  int counter = 0;
  while (getline(ref, refline) && getline(cand, candline)) {
    ++counter;
    float refscore, candscore;
    istringstream refentry(refline.c_str());
    istringstream candentry(candline.c_str());
    assert(refentry >> refscore);
    assert(candentry >> candscore);
    int len = 0;
    string word;
    while (refentry >> word)
      ++len;
    assert(len >= 1 && len <= order);
    // only interested in zero entries in refpath
    switch (error_code) {
    case FALSEPOS:
      assert(refscore >= 0);  // count data
      if (len > 1) // since unigrams detected as OOV
	if (refscore <= 0 + FLOATERR) {  // zero count reference
	  if (candscore > refscore + FLOATERR)  // overestimate
	    ++errors[len-1];  // single error
	  ++totals[len-1];  // number of negatives
	}
      break;
    case FALSENEG:
      assert(refscore >= 0); // count data
      if (refscore > 1 - FLOATERR) { // nonzero count
	if (candscore < FLOATERR)  // zero
	  ++errors[len-1];
	++totals[len-1];
      }
      break;
    case ADDERROR:
      // for zeros only
      if (refscore > 0)
	break;
      errors[len-1] += fabs(refscore - candscore);  // additive
      ++totals[len-1];
      break;
    case RELERROR:
      // get relative absolute error
      if (refscore > 0) {
	errors[len-1] += (fabs(refscore - candscore) / fabs(refscore));  // relative error
	++totals[len-1];  // number of observations
      }
      break;
    case ABSMSE:
      errors[len-1] += (refscore - candscore) * (refscore - candscore);      
      ++totals[len-1];
      break;
    case RELMSE:
      if (fabs(refscore) > 0) {
	errors[len-1] += ((refscore - candscore) / (refscore)) * ((refscore - candscore) / (refscore));
	++totals[len-1];
      }
      break;
    case ABSTHRESHOLD:
      errors[len - 1] = fabs(refscore - candscore) > eps ? errors[len-1] + 1 : errors[len-1];
      ++totals[len-1];
      break;
    case RELTHRESHOLD:
      if (refscore > 0) {
	errors[len - 1] = fabs(refscore - candscore) / fabs(refscore) > eps 
	  ? errors[len-1] + 1 : errors[len-1];
	++totals[len-1];
      }
      break;
    }
    // get detailed errors
    if (counterrs.count(refscore) == 0) {
      counterrs[refscore] = 0;
      counterrstotals[refscore] = 0;
      poserrs[refscore] = 0;
      negerrs[refscore] = 0;
    }
    ++counterrstotals[refscore];
    if (refscore > candscore)
      //++negerrs[refscore];
      negerrs[refscore] +=  fabs(refscore - candscore) / fabs(refscore);
    if (refscore < candscore) {
      if (refscore > 0)
	poserrs[refscore] +=  fabs(refscore - candscore) / fabs(refscore);
      else
	poserrs[refscore] +=  fabs(refscore - candscore);
    }
    if (refscore > 0) {
      if (fabs(refscore - candscore) / fabs(refscore) > 0.001)
	counterrs[refscore] +=  fabs(refscore - candscore) / fabs(refscore);
    } else {
      if (fabs(refscore - candscore)  > 0.001)
	counterrs[refscore] +=  fabs(refscore - candscore);
    } 
 
  }
  std::cerr << "read " << counter << " entries." << std::endl;
  // write details to cerr
  for(map<float,float>::const_iterator citer = counterrs.begin(); citer != counterrs.end(); ++citer) {
    if ((float)counterrstotals[citer->first]/(float)counter > 0.001)
      std::cerr<< citer->first << "\t" << citer->second/counterrstotals[citer->first]
  		<< "\t" << (float)poserrs[citer->first]/(float)counterrstotals[citer->first]
  		<< "\t" << (float)negerrs[citer->first]/(float)counterrstotals[citer->first]
  		<< "\t" << ((float)counterrstotals[citer->first]/(float)counter) << std::endl;
  }
  // output errors and totals
  int totalsample = 0;
  float totalerror = 0; 
  for (int i = 0; i < order; ++i) {
    totalsample += totals[i];
    totalerror += errors[i];
    cerr << (i+1) << "\t" << (totals[i] > 0 ? errors[i]/static_cast<float>(totals[i]) : 0) 
	 << "\t" << totals[i] << endl;
  }
  cout << (totalsample > 0 ? totalerror/static_cast<float>(totalsample) : 0) << endl;
  return true;
}

int main(int argc, char** argv) {
  if (argc < 5 || atoi(argv[4]) < 0 || atoi(argv[4]) > 7) {
    cerr << "usage ./errorrate <reffile> <candfile> <order> <errorcode> (<eps>)\n"
	 << " errorcodes: 0 = false pos rate, 1 = false neg rate, 2 = adderror  \n"
	 << " 3 = relerror, 4 = abs mse, 5 = rel mean squared error, 6 = abs threshold prob \n" 
	 << " 7 = rel threshold prob " << endl;
    exit(1);
  } 
  float eps = 0;
  if (atoi(argv[4]) > 5){
    if (argc != 6)
      exit(1);
    else
      eps = atof(argv[5]);
    std::cerr << "Epsilon = " << eps << std::endl;
  }

  assert(errorrate(argv[1], argv[2], atoi(argv[3]), atoi(argv[4]), eps));
  return 0;
}
